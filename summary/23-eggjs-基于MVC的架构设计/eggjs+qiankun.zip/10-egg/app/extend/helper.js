module.exports = {
  json({ data = null, msg = '请求成功' }) {
    this.ctx.body = {
      code: 200,
      data,
      msg,
    }
    this.ctx.status = 200
  },
  success({ msg = null }) {
    this.ctx.body = {
      code: 200,
      msg,
      data: null,
    }
  },
}

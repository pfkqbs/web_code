const Subscription = require('egg').Subscription
class UpdateCache extends Subscription {
  //
  static get schedule() {
    return {
      interval: '5s',
      type: 'all',
      immediate: true,
    }
  }
  async subscribe() {
    console.log('任务执行了:' + new Date().toString())
    const res = await this.ctx.curl('https://free-api.heweather.net/s6/weather/now?location=hainan&key=b1eac8ade8b749bfb154b194a06964a4', {
      dataType: 'json',
    })
    // console.log(res.data)
    this.ctx.app.cache = res.data;
  }
}
module.exports = UpdateCache

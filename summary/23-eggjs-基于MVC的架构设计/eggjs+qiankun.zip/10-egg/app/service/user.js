const Service = require('egg').Service

class UserService extends Service {
  async create(payLoad) {
    const { ctx } = this
    // 与model打交道
    return ctx.model.User.create(payLoad)
  }
  async list() {
    const { ctx } = this
    // 与model打交道
    return ctx.model.User.find()
  }
  async detail(_id) {
    const { ctx } = this
    // 与model打交道
    return ctx.model.User.findById({ _id })
  }
  async update(_id, payload) {
    const { ctx } = this
    // 与model打交道
    return ctx.model.User.findByIdAndUpdate({ _id }, payload)
  }
  async delete(_id) {
    const { ctx } = this
    // 与model打交道
    return ctx.model.User.findByIdAndDelete({ _id })
  }
}

module.exports = UserService

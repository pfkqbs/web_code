'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  router.get('/', controller.home.index);

  // 用户的crud
  router.post('/api/v1/user',controller.user.create)
  router.get('/api/v1/user',controller.user.list)
  router.get('/api/v1/user/:id',controller.user.detail)
  router.put('/api/v1/user/:id',controller.user.update)
  router.delete('/api/v1/user/:id',controller.user.delete)
};

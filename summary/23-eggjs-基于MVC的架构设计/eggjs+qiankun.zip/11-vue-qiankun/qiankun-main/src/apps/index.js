import { registerMicroApps, start } from 'qiankun'

registerMicroApps([
  {
    name: 'monitor',
    entry: '//localhost:8070',
    container: '#monitor',
    activeRule: '/monitor',
    props: {
      base: '/',
    },
  },
])
// 启动 qiankun
start()

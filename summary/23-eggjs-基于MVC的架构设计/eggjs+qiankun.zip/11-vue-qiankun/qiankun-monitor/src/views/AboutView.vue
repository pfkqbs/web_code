<template>
  <div class="about">
    <h1>我是监控页面首页</h1>
  </div>
</template>

<template>
  <div class="home">我是监控页面首页</div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'HomeView',
}
</script>

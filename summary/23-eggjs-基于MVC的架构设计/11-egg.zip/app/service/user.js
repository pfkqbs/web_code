'use strict'

const Service = require('egg').Service

class UserService extends Service {
  async create(payload) {
    const { ctx } = this
    return ctx.model.User.create(payload)
  }
  async index() {
    return this.ctx.model.User.find()
  }
  async detail(_id) {
    return this.ctx.model.User.findById({ _id })
  }
  async update(_id, payload) {
    return this.ctx.model.User.findByIdAndUpdate({ _id }, payload)
  }
  async delete(_id) {
    return this.ctx.model.User.findByIdAndDelete({ _id })
  }
}

module.exports = UserService

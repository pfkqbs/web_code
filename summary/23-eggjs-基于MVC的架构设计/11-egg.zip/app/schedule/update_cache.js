const Subscription = require('egg').Subscription;
class UpdateCache extends Subscription {
  // 通过 schedule 属性来设置定时任务的执行间隔等配置
  static get schedule() {
    return {
      interval: '5s', // 1 分钟间隔
      type: 'all', // 指定所有的 worker 都需要执行
      immediate: true
    };
  }
  // subscribe是真正定时任务执行时被运行的函数
  async subscribe() {
    console.log("任务执行 : " + new Date().toString());

    // const res = await this.ctx.curl('https://free-api.heweather.net/s6/weather/now?location=beijing&key=4693ff5ea653469f8bb0c29638035976', {
    //   dataType: 'json',
    // })
    // console.log(res)
    // this.ctx.app.cache = res.data;
  }
}
module.exports = UpdateCache;


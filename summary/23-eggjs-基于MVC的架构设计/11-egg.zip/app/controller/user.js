// eggjs
'use strict'

const Controller = require('egg').Controller

class UserController extends Controller {
  constructor(props) {
    super(props)
    this.UserCreateRule = {
      username: {
        type: 'string',
        require: true,
        allowEmpty: false,
        // 用户名必须是3-10位之间的字母、下划线、@、. 并且不能以数字开头
        format: /^[A-Za-z_@.]{3,10}/,
      },
      password: {
        type: 'string',
        require: true,
        allowEmpty: false,
        min: 6,
      },
    }
  }
  // 创建用户
  async create() {
    const { ctx, service } = this
    // 校验参数
    ctx.validate(this.UserCreateRule)
    // ctx.request.body
    const payLoad = ctx.request.body || {}
    const res = await service.user.create(payLoad)
    ctx.body = {
      res,
    }
  }
  // 获取用户列表
  async index() {
    const { ctx, service } = this
    const res = await service.user.index()
    // ctx.body = res
    ctx.helper.json({ data: res })
  }
  async detail() {
    const { ctx, service } = this
    const _id = ctx.params.id
    const res = await service.user.detail(_id)
    ctx.body = res
  }
  async update() {
    const { ctx, service } = this
    const _id = ctx.params.id
    const payload = ctx.request.body
    const res = await service.user.update(_id, payload)
    ctx.body = { msg: '操作成功' }
  }
  async delete() {
    const { ctx, service } = this
    const _id = ctx.params.id
    const res = await service.user.delete(_id)
    ctx.body = { msg: '操作成功' }
  }
}

module.exports = UserController

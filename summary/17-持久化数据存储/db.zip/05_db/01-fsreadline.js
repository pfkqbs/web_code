const FILEPATH = './db/my.json'
const fs = require('fs');
function get(key) {
    fs.readFile(FILEPATH, (err, data) => {
        const json = JSON.parse(data);
        console.log(json[key]);
    })
}

function set(key, value) {
    fs.readFile(FILEPATH, (err, data) => {        
        // 可能是空文件,则设置为空对象
        const json = data.toString() ? JSON.parse(data) : {};
        json[key] = value; //设置值
        // 重新写入文件
        fs.writeFile(FILEPATH, JSON.stringify(json), err => {
            if (err) console.log(err);
            console.log('写入成功');
        })
    })
}

// 命令行接口部分
const readline = require('readline');
//创建实例
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
//监听命令行的输入
rl.on('line', (input) => {
    const [op, key, value] = input.split(' ');
    if (op === 'get') {
        get(key);
    } else if (op === 'set') {
        console.log(key, value);

        set(key, value);
    } else if (op === 'quit') {
        rl.close();
    } else {
        console.log('没有该操作');

    }

});
// 程序结束
rl.on('close', () => {
    console.log('程序结束');
    process.exit(0);
})


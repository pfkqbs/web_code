const mongodb = require('./index.js')
mongodb.once('connect', async () => {
  const col = mongodb.col('students')
  // 插入测试数据
  try {
    // 删除已存在的
    await col.deleteMany()

    await col.insertMany([
      {
        name: '张三',
        age: 20,
        score: 90,
        class: 1,
      },
      {
        name: '李四',
        age: 30,
        score: 100,
        class: 2,
      },
      {
        name: '王五',
        age: 30,
        score: 70,
        class: 1,
      },
      {
        name: '赵六',
        age: 18,
        score: 60,
        class: 3,
      },
      {
        name: '小马哥',
        age: 18,
        score: 80,
        class: 1,
      },
      {
        name: '小马哥2',
        age: 18,
        score: 80,
        class: 1,
      },
      {
        name: '小马哥3',
        age: 18,
        score: 80,
        class: 1,
      },
      {
        name: '小马哥4',
        age: 18,
        score: 80,
        class: 1,
      },
      {
        name: '小马哥5',
        age: 18,
        score: 80,
        class: 1,
      },
      {
        name: '小马哥6',
        age: 18,
        score: 80,
        class: 1,
      },
    ])
    console.log('测试数据插入成功')
  } catch (error) {
    console.log('测试数据插入失败', error)
  }
})

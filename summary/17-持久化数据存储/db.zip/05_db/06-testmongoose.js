const mongoose = require('mongoose')
mongoose.connect('mongodb://127.0.0.1/test')
const db = mongoose.connection
db.on('error', console.error.bind(console, 'connection error:'))
db.once('open', async () => {
  // we're connected!
  // 定义一个schema =>表
  // 字段
  const blogSchema = new mongoose.Schema({
    title: String,
    author: String,
    body: String,
    comments: [
      {
        body: String,
        date: Date,
      },
    ],
    date: {
      type: Date,
      default: Date.now,
    },
    hidden: Boolean,
    meta: {
      votes: Number,
      favs: Number,
    },
  })
  // 定义实例方法 (schema对象上的方法)
  blogSchema.methods.findAuthor = function () {
    return this.model('Blog').find({ author: this.author }).exec()
  }
  // 定义静态方法 (模型上的方法)
  blogSchema.statics.findTitle = function (title) {
    return this.find({ title: title }).exec()
  }

  // 定义虚拟属性
  blogSchema.virtual('getContent').get(function () {
    return `${this.author}发布了一篇文章叫${this.title}`
  })

  // 定义一个模型
  const Blog = mongoose.model('Blog', blogSchema)
  try {
    await Blog.deleteMany()
    // 后添加
    await Blog.insertMany([
      {
        title: 'Vue基础',
        author: '小尤',
        body: 'Vue是一个轻量级的高效的牛逼前端框架',
        comments: [
          {
            body: '您说的对，非常认同',
            date: new Date(),
          },
        ],
        hidden: true,
        meta: {
          votes: 10,
          favs: 200,
        },
      },
      {
        title: 'React',
        author: 'faceBook',
        body: 'React是更牛逼前端框架',
        comments: [
          {
            body: '您说的似对似不对，不是那么认同',
            date: new Date(),
          },
        ],
        hidden: false,
        meta: {
          votes: 400,
          favs: 2000,
        },
      },
    ]) //插入多条数据
    console.log('插入数据成功')

    // 查询操作
    // find() findOne() findById()
    // let r = await Blog.find({ author: '小尤' })
    // let r = await Blog.find().and([
    //   {
    //     author: 'faceBook',
    //   },
    //   {
    //     title: 'React',
    //   },
    // ])

    // // 在下面一定要多看文档，当你的需求是做不同的操作的时候结合文档 进行实现
    // let b = new Blog({ author: '小尤' })
    // r = await b.findAuthor()
    // r = await Blog.findTitle('Vue基础')
    // console.log('更新结果', r)

    // // 5e66faf1d7886659dbf85b10

    // // 查询一条结果 根据_id获取
    let sid = mongoose.Types.ObjectId('62b6759c4d54263c995694dc')
    r = await Blog.findOne({ _id: sid })
    console.log('更新结果', r)


    r = await Blog.findOne({ author: '小尤' })
    // console.log(r.getContent)

    // // 更新
    r = await Blog.where({ author: '小尤' }).updateOne({ title: '哈哈哈哈' })
    console.log('更新结果',r);
    // 更新并返回当前查询的结果
    r = await Blog.findOneAndUpdate(
      { author: '小尤' },
      { author: '大马哥' },
      { new: true }
    )
    console.log('查询结果为', r)

    // 删除操作
    r = await Blog.deleteOne({ author: '大马哥' })
    console.log('删除成功',r.deletedCount); //r.deletedCount 如果等于 表示 更新或删除成功

    // 删除
  } catch (error) {
    console.log(error)
  }
})

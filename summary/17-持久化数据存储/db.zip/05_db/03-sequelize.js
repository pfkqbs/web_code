const { Sequelize, DataTypes } = require('sequelize')
const Op = Sequelize.Op
// 建立连接
const sequelize = new Sequelize('db1', 'root', '', {
  host: '127.0.0.1',
  dialect: 'mysql',
})
;(async function () {
  try {
    await sequelize.authenticate()
    console.log('数据库连接成功')
  } catch (error) {
    console.log(error)
  }
})()

// 定义模型
const Books = sequelize.define(
  'books',
  {
    id: {
      type: DataTypes.INTEGER, // 定义数据类型
      primaryKey: true, //设置主键
      autoIncrement: true, //设置自增长
      comment: '自增id', // 添加注释
    },
    name: {
      type: DataTypes.STRING(50),
      allowNull: false, // 不允许为空 默认为true
    },
    price: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },
    count: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
  },
  {
    // 是否将设置createAt和updateAt字段，默认true，是创建
    timestamps: false,
    // 表名冻结
    freezeTableName: true,
    // 定义getter和setter方法
    // getterMethods: {
    //   amount() {
    //     return 'xxx'
    //   },
    // },
    // setterMethods:{

    // }
  }
)
// 迁移模型映射到数据
Books.sync({ force: true }).then(async () => {
  //添加一条数据
  //   Books.create({
  //     name: 'javascript高级编程',
  //     price: 99.9,
  //     count: 100,
  //   })
  // 添加多条数据
  Books.bulkCreate([
    {
      name: '你不知道的JavaScript',
      price: 2.9,
      count: 10,
    },
    {
      name: 'Vue实战开发',
      price: 100.9,
      count: 100,
    },
    {
      name: 'React实战开发',
      price: 122.9,
      count: 88,
    },
    {
      name: 'Nodejs实战',
      price: 122.9,
      count: 100,
    },
  ])
  //   1.查询所有的书籍
  //   const books = await Books.findAll()
  //   const books = await Books.findAll({ attributes: ['name', 'count'] })
  //   const books = await Books.findAll({ attributes: ['name', ['count','inventory']] })
  const books = await Books.findAll({
    attributes: { exclude: ['name'] },
    // where: {
    //   id: 1,
    // },
    // where: {
    //   id: {
    //     [Op.eq]: 1,
    //   },
    //   name:'张三'
    // },
    // where: {
    //   [Op.or]: [{ id: 1 }, { id: 4 }],
    // },
    order: [['id', 'DESC']],
    limit: 2,
    offset: 1,
  })
  const counts = await Books.count('id')
  const maxPrice = await Books.max('price')
  const minPrice = await Books.min('price')
  const sumPrice = await Books.sum('price')
  console.log(sumPrice)

  //   console.log('all books:', JSON.stringify(books, null, 2))
})

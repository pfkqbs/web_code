// 下载
const MongoClient = require('mongodb').MongoClient

;(async function () {
  const client = new MongoClient('mongodb://127.0.0.1:27017', {
    useNewUrlParser: true,
  })
  // 链接服务端
  await client.connect()
  console.log('链接成功')

  // 获取数据库
  const db = client.db('school')
  const grade1 = db.collection('grade1')

  // 先删除所有的数据
  grade1.deleteMany()
  //   插入一条数据
  // grade1.insertOne({
  //   name:"张三",age:20,hobby:['吃饭','睡觉','打豆豆'],score:90
  // })
  // grade1.insertMany([]);

  // CRUD
  // 查询操作
  let r = await grade1.insertMany([
    { name: '张三', age: 20, hobby: ['吃饭', '睡觉', '打豆豆'], score: 90 },
    { name: '李四', age: 40, hobby: ['妹子', '篮球'], score: 93 },
    { name: '王五', age: 20, hobby: ['妹子', '睡觉'], score: 70 },
    { name: '赵六', age: 16, hobby: ['妹子'], score: 50 },
    { name: '张丽', age: 38, hobby: ['妹子'], score: 56 },
    { name: '小红', age: 40, hobby: ['妹子'], score: 87 },
    { name: '小马', age: 20, hobby: ['妹子'], score: 79 },
    { name: '小王', age: 59, hobby: ['妹子'], score: 102 },
    { name: '小黑', age: 16, hobby: ['妹子'], score: 60 },
    { name: '小马哥', age: 18, hobby: ['篮球'], score: 49 },
  ])
//   console.log('插入成功', r)
  // 查询文档的操作 获取一条数据
//   r = await grade1.findOne({ name: '张三' })
//   //selert * from grade1
//   r = await grade1.find().toArray()
//   r = await grade1.find({ name: '张三' }).toArray()
//   // 比较运算符
//   r = await grade1
//     .find({
//       age: {
//         // gt大于 lt小于  gte 大于等于  lte小于等于
//         $gte: 20,
//       },
//     })
//     .toArray()

//   // 逻辑运算符  $and  $or $ne  $nor 不等于
//   // 查询姓名叫王五并且年龄为20岁的人
//   r = await grade1
//     .find({
//       name: '王五',
//       age: 20,
//     })
//     .toArray()
//   // 查询姓名叫张三或者年龄为20岁的人
//   r = await grade1
//     .find({
//       $or: [
//         {
//           name: '张三',
//         },
//         {
//           age: 20,
//         },
//       ],
//     })
//     .toArray()

//   // // 查询年龄不大于20岁并且age不小于16的人员
//   r = await grade1
//     .find({
//       $nor: [
//         {
//           age: {
//             $gt: 20,
//           },
//         },
//         {
//           age: {
//             $lt: 16,
//           },
//         },
//       ],
//     })
//     .toArray()

//   // 正则表达式
//   r = await grade1
//     .find({
//       name: {
//         $regex: /^张/,
//       },
//     })
//     .toArray()

//   // $all $in $size
//   // 查找指定字段包含所有指定内容的数据
//   r = await grade1
//     .find({
//       hobby: {
//         $all: ['妹子'],
//       },
//     })
//     .toArray()

//   // 查找指定字段只有指定内容其一的数据
//   r = await grade1
//     .find({
//       hobby: {
//         $in: ['妹子', '睡觉'],
//       },
//     })
//     .toArray()

//   // 查找指定字段的数据有三条的
//   r = await grade1
//     .find({
//       hobby: {
//         $size: 3,
//       },
//     })
//     .toArray()

//   // 分页查询  limit()
//   // 查询前两条数据
//   r = await grade1.find().limit(2).toArray()

//   // 跳过前2条数据,获取后4条数据
//   r = await grade1.find().skip(2).limit(4).toArray()
//   // 根据age字段进行排序 1表示正序  -1 表示倒序
//   r = await grade1
//     .find()
//     .sort({
//       age: -1,
//     })
//     .toArray()

//   // 分页
//   const pageIndex = 1 //当前的索引
//   const pageSize = 3 //当前一页显示的数据
//   // 1  2  3 4
//   r = await grade1
//     .find()
//     .skip((pageIndex - 1) * pageSize)
//     .limit(pageSize)
//     .toArray()

//   // // 数组 forEach方法 map()方法
//   // r.forEach(element => {
//   //   // console.log(element);

//   // });
//   // 所有的名字返回给前端 一个数组
//   let names = r.map((ele) => ele.age)
//   // console.log(names);
//   // 聚合函数 $sum $min $max $avg
//   // 相同年龄的人数
//   r = await grade1
//     .aggregate([
//       {
//         $group: {
//           _id: '$age',
//           count: {
//             $sum: 1,
//           },
//         },
//       },
//     ])
//     .toArray()

//   r = await grade1
//     .aggregate([
//       {
//         $group: {
//           _id: '$age',
//           avgScore: {
//             $avg: '$score',
//           },
//         },
//       },
//     ])
//     .toArray()
//   r = await grade1
//     .aggregate([
//       {
//         $group: {
//           _id: '$age',
//           avgScore: {
//             $max: '$score',
//           },
//         },
//       },
//     ])
//     .toArray()
//   console.log(r)

//   // // 更新文档
//   // r = await grade1.updateOne(
//   //   {
//   //     name: "张三",
//   //   },
//   //   {
//   //     $set:{
//   //       name:"小马哥"
//   //     }
//   //   }
//   // )
//   // console.log('更新成功',r.result )
//   // 当你做删除的时候 一定要问一下自己 是否要删除
//   r = await grade1.deleteOne({
//     name: '张三',
//   })
  console.log(r)

  // 关闭客户端的链接
  client.close()
})()

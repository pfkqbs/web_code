/* 
    Salvatore Sanfilippo
    萨尔瓦多·桑菲利波普   
    Prvital公司 
使用redis的优势
    1、性能高 速度快
        数据存储内存中，直接与内存连接
        相对底层的c语言实现，离操作系统最近
        实现源码很精湛
        使用单线程模型，无多线程的竞争 锁等问题

    2、丰富的数据接口
        哈希 列表  集合、有序集合

    3、特性
        过期功能 定时缓存
        支持 订阅、发布，消息队列
        支持事务
        支持供管道功能，批量处理多条命令
        支持lua 脚本功能
        支持集群分片和数据复制功能
        支持内存数据持久化硬盘功能
 */

const express = require('express')
const axios = require('axios')
const Redis = require('ioredis')

const PORT = process.env.PORT || 5000
const REDiS_PORT = process.env.REDiS_PORT || 6379

const app = express()
const redis = new Redis({ port: 6379, host: '127.0.0.1' })

// Cache middleware
function cache(req, res, next) {
  const { username } = req.params
  redis.get(username, (err, data) => {
    if (err) throw err
    if (data !== null) {
      console.log('缓存中有数据，返回', data)
      // 缓存中有数据，返回缓存中的数据
      res.send(setResponse(username, data))
    } else {
      console.log('缓存中没有数据，继续请求')
      // 否则继续之前的请求
      next()
    }
  })
}

// 设置响应
function setResponse(username, repos) {
  return `<h2>${username} has ${repos} Github repositories</h2>`
}
// 获取github仓库数量
async function getRepos(req, res, next) {
  try {
    console.log('Fetching Data...')
    const { username } = req.params
    const response = await axios.get(`https://api.github.com/users/${username}`)
    const data = response.data
    const repos = data.public_repos
    // 存到redis
    // 三个参数分别是键、有效期、值
    await redis.set(username, repos)
    await redis.expire(username, 3600)

    res.send(setResponse(username, repos))
  } catch (error) {
    console.error(error)
    res.status = 500
  }
}
// 使用中间件，加上第二个参数cache
app.get('/repos/:username', cache, getRepos)

app.listen(5000, () => {
  console.log(`App listening on port ${PORT}`)
})

const express = require('express');
const app = express();
const path = require('path');
const mongod = require('./db')
const testData = require('./db/testData')
const ObjectId = require('mongodb').ObjectId;
// app.use(express.json());//json
app.use(express.urlencoded({extended:true}));//x-www-urlencoded
app.get('/', (req, res) => {
  // 做重定向路由
  res.redirect('/classes')
})
app.get('/classes', (req, res) => {
  res.sendFile(path.resolve(__dirname + '/classes.html'))
})
// get
// post
// delete

// 定义所有班级内容的接口
app.get('/api/classList', async (req, res) => {
  let { pageSize, pageIndex } = req.query;
  pageSize = Number(pageSize)
  pageIndex = Number(pageIndex)
  // console.log(pageSize,pageIndex);
  // http://localhost:3000/api/classList?pageSize=4&pageIndex=2
  // 链接数据库 
  // 获取集合对象 
  const students = mongod.col('students');
  const total = await students.countDocuments();
  // 调用find()获取所有的数据 
  const classList = await students.find().skip((pageIndex - 1) * pageSize).limit(pageSize).toArray();
  res.json({
    ok: 1,
    data: classList,
    total
  })
})

// 删除 post请求
app.post('/api/deleteUser',(req, res, next)=>{next()},async (req,res)=>{
  const {_id} = req.body;
  console.log(_id)
  const students = mongod.col('students');
  const r = await students.deleteOne({
    _id: ObjectId(_id)
  })
  if(r.deletedCount === 1){
    res.json({ ok: 1 ,msg:'删除数据成功'})
  }
})


app.listen(5001, () => {
  console.log('3000端口 被监听了');
})
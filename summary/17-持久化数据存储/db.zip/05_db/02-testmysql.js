const mysql = require('mysql')
// 创建链接对象
const conn = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: '',
  database: 'db1',
})

conn.connect((err) => {
  if (err) throw err
  console.log('数据库连接成功')
})
const CREAET_TABLE_SQL = `CREATE TABLE IF NOT EXISTs test(id INT NOT NULL PRIMARY KEY auto_increment,name VARCHAR(20))`
const INSER_TABLE_SQL = `INSERT INTO test(name) VALUES(?),(?)`
const SELECT_TABLE_SQL = `SELECT * FROM test WHERE id=?`
const DELECT_TABLE_SQL = `DELETE FROM test WHERE id=?`
// conn.query(CREAET_TABLE_SQL, (err, results, fields) => {
//   if (err) throw err
//   // 插入
//   conn.query(
//     INSER_TABLE_SQL,
//     ['小马哥', 'monono'],
//     (error, results, fields) => {
//       if (error) throw error
//       //   console.log(results)
//       conn.query(SELECT_TABLE_SQL, [2], (err, results, fields) => {
//         console.log(results)
//         // 断开链接
//         conn.end()
//       })
//     }
//   )
// })

conn.query(DELECT_TABLE_SQL, [2], (err, results) => {
  if (err) throw err
  console.log(results)
  conn.end()
})

const ReplyController = require("../controller/ReplyController");
const jwtAuth = require("koa-jwt");
module.exports = (router) => {
  // 创建回复
  router.post("/reply", ReplyController.createReply);
  // 获取评论的回复列表
  router.get("/reply", ReplyController.getReplyList);
  // 回复详情
  router.get("/reply/:_id", ReplyController.getReplyDetailById);
  // 更新单个回复
  router.put(
    "/reply/:_id",
    jwtAuth({ secret: global.config.security.secretKey }),
    ReplyController.updateReplyById
  );
  // 删除回复
  router.delete(
    "/reply/:_id",
    jwtAuth({ secret: global.config.security.secretKey }),
    ReplyController.deleteReplyById
  );
};

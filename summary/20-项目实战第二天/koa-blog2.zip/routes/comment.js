const CommentController = require("../controller/CommentController");
const jwtAuth = require("koa-jwt");
module.exports = (router) => {
  router.post("/comment", CommentController.createComment);
  //获取评论列表接口
  router.get("/comment", CommentController.getCommentList);
  router.get("/comment/:_id", CommentController.getCommentDetailById);
  const secretKey = global.config.security.secretKey;
  router.put(
    "/comment/:_id",
    jwtAuth({ secret: secretKey }),
    CommentController.updateCommentById
  );
  // 删除评论接口
  router.delete(
    "/comment/:_id",
    jwtAuth({ secret: secretKey }),
    CommentController.deleteCommentById
  );
};

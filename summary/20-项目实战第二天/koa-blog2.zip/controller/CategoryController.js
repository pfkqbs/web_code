const { categoryValidator } = require("../validators/category.js");
const CategoryModel = require("../models/CategoryModel");
const res = require("../core/helper");
class CategoryController {
  static async create(ctx, next) {
    // 参数校验
    categoryValidator(ctx);
    const { name, keyword } = ctx.request.body;
    const hasCategory = await CategoryModel.findOne({ name });
    if (hasCategory) throw new global.errs.Existing("分类名已存在");

    await CategoryModel.create({ name, keyword });
    ctx.body = res.success("创建分类成功");
  }
  static async getCategoryList(ctx, next) {
    const { pageIndex = 1, pageSize = 10 } = ctx.query;
    // 获取整个分类的总数
    const totalSize = await CategoryModel.find().countDocuments();
    console.log(typeof pageIndex);
    const categoryList = await CategoryModel.find()
      .skip(parseInt(pageIndex - 1) * parseInt(pageSize))
      .limit(parseInt(pageSize))
      .sort({ _id: -1 });
    ctx.body = res.json({
      content: categoryList,
      totalSize,
      pageIndex: parseInt(pageIndex),
      pageSize: parseInt(pageSize),
    });
  }
  // 更新分类
  static async updateCategoryById(ctx, next) {
    const _id = ctx.params._id;
    const { name, keyword } = ctx.request.body;
    const category = await CategoryModel.findByIdAndUpdate(
      { _id },
      { name, keyword }
    );
    if (!category) throw new global.errs.NotFound("没有找到相关分类");
    ctx.body = res.json("更新成功");
  }
  // 删除分类
  static async deleteCategoryById(ctx, next) {
    const _id = ctx.params._id;
    const category = await CategoryModel.findByIdAndDelete({ _id });
    if (!category) throw new global.errs.NotFound("没有找到相关分类");
    ctx.body = res.json("删除成功");
  }
}
module.exports = CategoryController;

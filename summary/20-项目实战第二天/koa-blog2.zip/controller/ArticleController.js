const ArticleModel = require("../models/ArticleModel");
const CommentModel = require("../models/CommentModel");
const ReplyModel = require("../models/ReplyModel");
const { articleValidator } = require("../validators/article");
const res = require("../core/helper");
class ArticleController {
  // 创建文章
  static async createArticle(ctx, next) {
    // 验证参数
    articleValidator(ctx);
    const { title } = ctx.request.body;
    const hasArticle = await ArticleModel.findOne({ title });
    if (hasArticle) {
      throw new global.errs.Existing("文章已存在");
    }
    await ArticleModel.create(ctx.request.body);
    ctx.body = res.success("创建成功");
  }
  //   获取文章列表
  static async getArticleList(ctx, next) {
    const {
      category_id = null,
      pageIndex = 1,
      pageSize = 10,
      keyword = null,
    } = ctx.query;
    let filter = null;
    if (category_id) {
      filter = {
        category_id,
      };
    }
    const totalSize = await ArticleModel.find().countDocuments();
    const articleList = await ArticleModel.find()
      .where(filter)
      .skip(parseInt(pageIndex - 1) * parseInt(pageSize))
      .limit(parseInt(pageSize))
      .or([
        //   模糊搜索查询
        {
          keyword: {
            $regex: new RegExp(keyword, "i"),
          },
        },
      ])
      .sort({ _id: -1 })
      .populate("category_id");
    ctx.body = res.json({
      content: articleList,
      pageIndex,
      pageSize,
      totalSize,
    });
  }

  //   更新文章
  static async updateArticeleById(ctx, next) {
    const _id = ctx.params._id;
    const article = await ArticleModel.findOneAndUpdate(
      { _id },
      ctx.request.body
    );
    if (!article) throw new global.errs.NotFound("没有找到相关文章");
    ctx.body = res.success("更新成功");
  }
  //   删除文章
  static async deleteArticelById(ctx, next) {
    const _id = ctx.params._id;
    const article = await ArticleModel.findOneAndDelete({ _id });
    if (!article) throw new global.errs.NotFound("没有找到相关文章");
    ctx.body = res.success("删除成功");
  }
  //   获取文章详情
  static async getArticleDetailById(ctx, next) {
    const _id = ctx.params._id;
    //   文章详情的内容
    const articleDetail = await ArticleModel.findById({ _id }).populate(
      "category_id"
    );
    if (!articleDetail) throw new global.errs.NotFound("没有找到相关分类");
    // 更新文章浏览器数 browse
    await ArticleModel.findByIdAndUpdate(
      { _id },
      { browse: ++articleDetail.browse }
    );
    //todo: 获取文章下的评论列表
    // 有点问题?
    const commentList = await CommentModel.find({ target_id: _id }).lean();
    // 内部再重新组装
    const newCommentList = await Promise.all(
      commentList.map(async (comment) => {
        let replayList = await ReplyModel.find({
          comment_id: comment._id,
        });
        comment.replayList = replayList;
        return comment;
      })
    );
    ctx.body = res.json({ articleDetail, commentList: newCommentList });
  }
}
module.exports = ArticleController;

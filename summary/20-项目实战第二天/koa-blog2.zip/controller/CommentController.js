const CommentModel = require("../models/CommentModel");
const { commentValidator } = require("../validators/comment");
const res = require("../core/helper");
class CommentController {
  static async createComment(ctx, next) {
    // 校验参数
    commentValidator(ctx);
    const {target_id} = ctx.request.body
    // 查询一下文章列表是否有 target_id
    // ArticleModel.find().where({_id:target_id})
    await CommentModel.create(ctx.request.body);
    ctx.body = res.success("创建评论成功");
  }
  // 获取评论列表
  static async getCommentList(ctx, next) {
    const { pageIndex = 1, pageSize = 10 } = ctx.query;
    // 获取总数
    const totalSize = await CommentModel.find().countDocuments();
    const commentList = await CommentModel.find()
      .skip(parseInt(pageIndex - 1) * pageSize)
      .sort([["_id", -1]])
      .limit(parseInt(pageSize));
    const data = {
      content: commentList,
      currentPage: parseInt(pageIndex),
      pageSize: parseInt(pageSize),
      totalSize,
    };
    ctx.body = res.json(data);
  }
  // 获取该评论的详情
  static async getCommentDetailById(ctx, next) {
    const _id = ctx.params._id;
    const commentDetail = await CommentModel.findById({ _id }).lean();
    if (!commentDetail) {
      throw new global.errs.NotFound("没有找到相关评论信息");
    }
    // todo: 获取该评论的回复列表
    const replyList = [];
    const data = {
      commentDetail,
      replyList,
    };
    ctx.status = 200;
    ctx.body = res.json(data);
  }
  // 更新评论
  static async updateCommentById(ctx, next) {
    const _id = ctx.params._id;
    const comment = await CommentModel.findByIdAndUpdate(
      { _id },
      ctx.request.body
    );
    if (!comment) {
      throw new global.errs.NotFound("没有找到相关评论");
    }
    ctx.body = res.success("更新评论成功");
  }
  // 删除评论
  static async deleteCommentById(ctx, next) {
    const _id = ctx.params._id;
    const comment = await CommentModel.findOneAndDelete({ _id });
    if (!comment) {
      throw new global.errs.NotFound("没有找到相关评论");
    }
    ctx.body = res.success("删除评论成功");
  }
  // 获取目标评论
  static async targetComment(params = {}) {
    const { target_id, pageIndex = 1 } = params;
    const pageSize = 4;
    // 获取所有的评论
    const commentList = await CommentModel.find({ target_id });
    return {
      commentList,
    };
  }
}
module.exports = CommentController;

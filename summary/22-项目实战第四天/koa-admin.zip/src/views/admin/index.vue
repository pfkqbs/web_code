<template>
  <section>
    <h1 style="text-align: center;margin-top: 100px">{{'小马哥'}}，欢迎您！</h1>
  </section>

</template>

<script>

  export default {
    components: {},

    data() {

      return {}
    },

    computed: {
     
    },

    methods: {}
  }
</script>

<style scoped>
  h1 {
    font-weight: normal;
  }
</style>


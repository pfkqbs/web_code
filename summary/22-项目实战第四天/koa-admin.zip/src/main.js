import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
// iView的使用
import ViewUI from 'view-design'
Vue.use(ViewUI)
import 'view-design/dist/styles/iview.css';
// 使用富文本的编辑器
import mavonEditor from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
Vue.use(mavonEditor);
// 导入默认的css模块
import './assets/style/admin.css'

// 接口测试
/* import admin from './api/admin';
(async function () {
  const res = await admin.login({
    nickname: '小马哥',
    password: "xiaomage123"
  })
  console.log(res);
  
})() */

Vue.config.productionTip = false

//全局的导航守卫
router.beforeEach(async (to,from,next)=>{
  const admin_token = localStorage.getItem('admin_token');
  if(admin_token){
    // 表示用户已登录 认证 放行 获取用户信息
    await store.dispatch('admin/adminAuth');
    next();
  }else{
    // 表示用户未登录
    if(to.meta.noAuth){
      next();
    }else{
      Vue.prototype.$Message.error('权限未授权');
      setTimeout(() => {
        next('/login');
      }, 1500);
    }
  }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
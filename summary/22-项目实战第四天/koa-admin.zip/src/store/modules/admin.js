import admin from '../../api/admin'
const state = {
  userInfo:{
    nickname:""
  }
};
const mutations = {
  SET_USER_INFO(state,userInfo){
    state.userInfo = userInfo
  }
 
};
const actions = {
  // 管理员登录
  async adminLogin({commit},params){
    return await admin.login(params);
  },
  // 令牌认证
  async adminAuth({commit},params){
    // 
    const res = await admin.auth(params);
    commit('SET_USER_INFO',res.data.data);
    return res;
  }
};
export default {
  namespaced:true,
  state,
  mutations,
  actions
}
import comments from '../../api/comments'
const state = {};
const mutations = {};
const actions = {
  async getCommentList({commit},params){
    return comments.list(params);
  },
  async destroyComment({commit},params){
    return comments.destroy(params);
  }
};
export default {
  namespaced: true,
  state,
  mutations,
  actions
}
import admin from '@/api/admin'
const state = {
  userInfo: null,
}
const mutations = {
  SET_USER_INFO(state, user) {
    state.userInfo = user
  },
  REMOVE_USER_INFO(state){
    state.userInfo = null
  }
}
const actions = {
  async adminLogin({ commit, state }, params) {
    try {
      let res = await admin.login(params)
      return res
    } catch (error) {}
  },
  async adminAuth({ commit }, params) {
    try {
      let res = await admin.auth(params)
      commit('SET_USER_INFO', res.data)
      return res
    } catch (error) {}
  },
}
export default {
  // 命名空间
  namespaced: true,
  state,
  mutations,
  actions,
}

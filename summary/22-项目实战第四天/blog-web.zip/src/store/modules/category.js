import category from '../../api/category'
const state = {
  // 分类列表
  categoryList: [],
  categoryIndex: 0,
}
const mutations = {
  SET_CATEGORY_LIST(state, list) {
    state.categoryList = list
  },
  SET_CATEGORY_INDEX(state, index) {
    state.categoryIndex = index
  },
}
const actions = {
  async list({ commit, state }, params) {
    // 做优化的步骤
    if (state.categoryList && state.categoryList.length > 0) {
      return state.categoryList
    }
    let res = await category.list(params)
    /* 
    code:200,
    data:{
      content:[]
    },
    msg:''
    */
    let categoryList = res?.data?.content
    categoryList.unshift({ name: '全部' })
    commit('SET_CATEGORY_LIST', categoryList)
    return res.data.data
  },
}
export default {
  // 命名空间
  namespaced: true,
  state,
  mutations,
  actions,
}

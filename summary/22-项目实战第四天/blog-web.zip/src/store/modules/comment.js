import comment from '../../api/comment'
const state = {
  // 评论列表
  commentList:[],
  // 评论页码
  commentPage:null
};
const mutations = {
  // 设置评论列表
  SET_COMMENT_LIST(state,list){
    state.commentList = list;
  },
  // 设置评论页码
  SET_COMMENT_PAGE(state,data){
    state.commentPage = data;
  }
};
const actions = {
  // 创建评论的方法
  // 异步操作
  async createComment({commit},params){
    return await comment.create(params);
  },
  // 获取该文章目标下的评论列表
  async getTargetComments({commit},params){
    return await comment.targetList(params);
  }
  
};
export default {
  // 命名空间
  namespaced: true,
  state,
  mutations,
  actions
}
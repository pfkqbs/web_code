const state = {};
const mutations = {};
const actions = {};
export default {
  // 命名空间
  namespaced: true,
  state,
  mutations,
  actions
}
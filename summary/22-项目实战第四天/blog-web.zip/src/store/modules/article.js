
import article from '../../api/articles'
const state = {
};
const mutations = {

};
const actions = {
  // 获取文章
  async list({commit,state},params){
    const res = await article.list(params);
    
    return res;
  },
  // 获取文章详情
  async detail({commit},params){
    const res = await article.detail(params);
    return res;
  }

};
export default {
  // 命名空间
  namespaced:true,
  state,
  mutations,
  actions
}
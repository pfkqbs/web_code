import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
// 使用element-ui中的组件
import './plugins/element'
// 移动端自适应配置
import 'lib-flexible/flexible.js'
// 使用富文本编辑器
// use
import mavonEditor from 'mavon-editor'
import 'mavon-editor/dist/css/index.css'
// 图片懒加载插件
import VueLazyload from 'vue-lazyload'
Vue.use(VueLazyload)
Vue.use(mavonEditor)

Vue.config.productionTip = false
// 路由守卫
router.beforeEach(async (to, from, next) => {
  const categoryIndex = localStorage.getItem('categoryIndex')
  if (categoryIndex) {
    store.commit('category/SET_CATEGORY_INDEX', categoryIndex);
    next();
  } else {
    next();
  }
  const token = localStorage.getItem('web_user_token');
  if (token) {
    // 表示用户已登录，需要认证，获取用户信息
    // try {
      await store.dispatch('admin/adminAuth');
      next();
    // } catch (error) {
    //   setTimeout(() => {
    //     next('/login');
    //   }, 500);
    // }
  } else {
    // 表示用户未登录
    if (to.meta.requireAuth) {
      // 需要登录
      next('/login');
    } else {
      next();
    }
  }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
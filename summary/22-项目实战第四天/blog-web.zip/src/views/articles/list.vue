<!--文章列表-->
<template>
  <section class="articles">
    <article class="article-list">
      <!-- 文章分类显示 -->
      <ul class="category" v-if="categoryList && categoryList.length > 0">
        <!-- <li class="category-item category-item-active">全部</li> -->
        <li
          class="category-item"
          v-for="(item, i) in categoryList"
          :key="item._id"
          :class="{ 'category-item-active': categoryIndex == i }"
          @click="changeCategory(item._id, i)"
        >
          {{ item.name }}
        </li>
        <!-- <li class="category-item">react</li> -->
      </ul>
      <!-- 文章组件-->
      <v-article-item :list="list" />

      <div class="page">
        <!-- 分页组件 -->
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page.sync="page.currentPage"
          :page-size="page.pageSize"
          layout="total, prev, pager, next"
          :total="page.total"
        ></el-pagination>
      </div>
    </article>
  </section>
</template>

<script>
import VArticleItem from './item'
import { mapState, mapActions } from 'vuex'
export default {
  components: {
    VArticleItem,
  },
  name: 'list',
  data() {
    return {
      list: [],
      page: {},
      currentPage: 1,
      // categoryIndex:0
    }
  },
  computed: {
    ...mapState({
      categoryList: (state) => state.category.categoryList,
      categoryIndex: (state) => state.category.categoryIndex,
    }),
  },
  async created() {
    await this.getCategoryList()
    await this.getArticles()
  },
  watch: {
    $route(to, from) {
      this.getArticles()
    },
  },
  methods: {
    ...mapActions({
      getCategoryList: 'category/list',
      getArticleList: 'article/list',
    }),

    // 获取所有文章
    async getArticles() {
      const params = {
        pageIndex: this.currentPage,
        pageSize: 4,
        category_id: this.$route.query.category_id,
        keyword: this.$route.query.keyword,
      }
      let res = await this.getArticleList(params)
      const { content, pageIndex, totalSize, pageSize } = res.data
      this.list = content
      this.page = { total: totalSize, pageSize, currentPage: pageIndex }
    },
    // 切换分类
    changeCategory(id, i) {
      // 控制样式
      this.$store.commit('category/SET_CATEGORY_INDEX', i)
      // 保存本地数据库
      localStorage.setItem('categoryIndex', i)
      this.$router.push({
        query: {
          category_id: id,
        },
      })
      // 获取所有的文章 因为有监听地址的功能 没有必要再发请求
      // this.getArticles();
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`)
      this.currentPage = val
      this.getArticles()
    },
  },
}
</script>

<style scoped lang="less">
.category {
  width: 100%;
  overflow: hidden;
  overflow-x: auto;
  height: 64px;
  line-height: 64px;
  display: flex;
  border-bottom: 1px solid #f0f0f0;
}

.category-item {
  margin-left: 32px;
  cursor: pointer;
  color: #515a6e;
  font-size: 16px;
  font-weight: normal;

  &:hover {
    color: #2d8cf0;
  }
}

.category-item-active {
  color: #2d8cf0;
}

.articles {
  width: 100%;
  display: flex;
  min-height: 80vh;
  margin: 24px auto;
}

.article-list {
  flex: 1;
  margin-right: 32px;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 1px 2px 3px #f0f0f0;
  background: #fff;
}

@media screen and (min-width: 200px) and (max-width: 750px) {
  .articles {
    width: 100%;
  }

  .article-list {
    margin-right: 0;
  }
}
</style>

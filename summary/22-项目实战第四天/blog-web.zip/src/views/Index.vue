<template>
  <div>
    <router-view />
  </div>
</template>

<script></script>

<style lang="less" scoped></style>

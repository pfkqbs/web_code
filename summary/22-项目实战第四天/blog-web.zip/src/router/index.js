import Vue from 'vue'
import VueRouter from 'vue-router'
import ArticleList from '../views/articles/list'

Vue.use(VueRouter)

const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err);
}

const routes = [{
    path: '/',
    redirect: '/home',
    name:"home",
    component:()=>import('@/views/Index.vue'),
    children:[
      {
        path:'/home',
        component: () => import('@/views/articles/list.vue')
      },
      {
        path: '/article/detail',
        name: "article-detail",
        meta:{
          requireAuth:true
        },
        component: () => import('../views/articles/detail.vue')
      },
      {
        path: '/about',
        name: 'About',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import( /* webpackChunkName: "about" */ '../views/About.vue')
      }
    ]
  },
  {
    path:'/login',
    name:'login',
    component:()=>import('../views/login/index.vue')
  }
]

const router = new VueRouter({
  routes,
  linkExactActiveClass: 'nav-item-active', //准确的活跃
})


export default router
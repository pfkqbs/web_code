<template>
  <div class="footer-inner">
      <p>www.cnblogs.com/majj - 小马哥博客 Copyright&copy;</p>
      <p><a href="http://www.miit.gov.cn" target="_blank">粤ICP备18001135号-3</a></p>
  </div>
</template>

<style lang="less" scoped>
  .footer-inner {
    text-align: center;
    font-size: 18px;
    color: #fff;
    background: #262626;
  }

  .footer-inner a {
    color: #fff;
    text-decoration: none;
  }
</style>


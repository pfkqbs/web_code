<template>
  <div id="app">
    <el-container>
      <el-header class="app-header">
        <MainHeader></MainHeader>
      </el-header>
      <el-container>
        <el-container>
          <el-main>
            <router-view></router-view>
          </el-main>
          <el-footer>
            <MainFooter></MainFooter>
          </el-footer>
        </el-container>
        <el-aside width="400px">
          <MainAside></MainAside>
        </el-aside>
      </el-container>
    </el-container>
  </div>
</template>
<script>
import MainFooter from '@/components/main-footer'
import MainHeader from '@/components/main-header'
import MainAside from '@/components/main-sidebar'
export default {
  components: {
    MainFooter,
    MainAside,
    MainHeader,
  },
}
</script>
<style lang="less" scoped>
.app-header {
  padding: 0;
}
.app-footer {
  padding: 50px;
}
</style>
<style lang="less">
/*使用公共的css代码块*/
// @import "./assets/css/common.less";
html,
body {
  margin: 0;
  padding: 0;
  background: #f0f0f0 !important;
  font-family: 'Helvetica Neue', Helvetica, 'PingFang SC', 'Hiragino Sans GB',
    'Microsoft YaHei', '微软雅黑', Arial, sans-serif;
}

ul,
li,
h1,
div,
dl,
dt,
dd {
  margin: 0;
  padding: 0;
  list-style: none;
}

#app {
  width: 100%;
  overflow: hidden;
  box-sizing: border-box;
}
</style>

import fetch from './fetch'
export default {
  // 创建回复
  login(params) {
    return fetch.post('/admin/login', params);
  },
  auth(params){
    return fetch.get('/admin/user/info',params);
  }
}
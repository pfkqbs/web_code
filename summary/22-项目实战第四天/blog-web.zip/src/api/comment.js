import fetch from './fetch'
export default {
  // 创建评论
  create(params) {
    return fetch.post('/comment', params);
  },
  targetList(params){
    // 后端接口 {pageIndex:1,target_id:文章id}
    return fetch.get('/comment/target/list',params);
  }
  
}
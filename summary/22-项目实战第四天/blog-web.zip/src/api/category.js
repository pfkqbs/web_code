import fetch from './fetch'
export default {
  // 获取分类列表
  list(params) {
    // http://localhost:5000/api/v1/category
    return fetch.get('/category',params);
  }
}
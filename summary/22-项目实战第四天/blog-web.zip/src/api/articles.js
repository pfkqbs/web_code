import fetch from './fetch'
export default {
  // 获取文章列表
  list(params) {
    // http://localhost:5000/api/v1/category
    return fetch.get('/article', params);
  },
  // 获取文章详情
  detail(params){   
    return fetch.get('/article/'+params.id)
  }
}
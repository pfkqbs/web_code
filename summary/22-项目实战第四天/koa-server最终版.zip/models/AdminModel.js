// 1.引入mongoose
const mongoose = require("mongoose");
// 对密码加盐处理
const bcrypt = require("bcrypt");
const SALT_WORK_FACTOR = 10;
// 2.定义Schema(描述文档结构)
const adminSchema = new mongoose.Schema({
  nickname: {
    type: String,
    require: true,
  },
  password: {
    type: String,
    require: true,
    set(val) {
      // 加密生成
      const salt = bcrypt.genSaltSync(SALT_WORK_FACTOR);
      //   生成hash密码
      const psw = bcrypt.hashSync(val, salt);
      return psw;
    },
  },
});
// 3.定义Model
const AdminModel = mongoose.model("Admin", adminSchema);

// 4.向外暴露
module.exports = AdminModel;

module.exports = {
  port: 3000,
  path: "/api/v1",
  //mongodb数据库相关配置
  db: {
    port: 27017,
    host: "127.0.0.1",
    dbName: "koaBlog", //数据库名称
  },
  // 签证配置
  security: {
    secretKey: "secretKey",
    expiresIn: Math.floor(Date.now() / 1000) + 60 * 60 * 24,
  },
};

const AdminModel = require("../models/AdminModel");
const { registerValidator, loginValidator } = require("../validators/admin");
const LoginManager = require("../services/login");
const res = require("../core/helper");
class AdminController {
  // 注册
  static async register(ctx, next) {
    //   参数校验
    registerValidator(ctx);
    //  处理业务
    //   nickname,password,password2
    const { nickname, password2 } = ctx.request.body;
    const currentUser = await AdminModel.findOne({ nickname });
    if (currentUser) {
      throw new global.errs.Existing("用户已存在", 900);
    }
    const user = await AdminModel.create({
      nickname,
      password: password2,
    });
    // ctx.body = {
    //   code: 200,
    //   msg: "success",
    //   data: user,
    //   errorCode: 0,
    // };
    ctx.body = res.json(user);
  }
  // 更新
  // 删除
  // 登录
  static async login(ctx, next) {
    loginValidator(ctx);
    /*
     */
    const { nickname, password } = ctx.request.body;
    console.log(nickname, password);
    /* 
    {
       nickname: user.nickname,
       token 
    }
    
    */
    const user = await LoginManager.adminLogin({ nickname, password });

    if (!user) {
      throw new global.errs.NotFound("用户不存在");
    }
    ctx.body = res.json(user, "登录成功");
  }
  // 获取用户登录信息  token
  static async getUserInfo(ctx, next) {
    console.log(ctx.state);
    const _id = ctx.state.user.data;
    // 查询用户信息
    const userInfo = await AdminModel.findById({ _id });
    if (!userInfo) throw new global.errs.AuthFailed("认证失败,请检查请求头");

    // ctx.body = {
    //   code: 200,
    //   message: "获取成功",
    //   data: {
    //     _id,
    //     nickname: userInfo.nickname,
    //   },
    // };
    ctx.body = res.json({ _id, nickname: userInfo.nickname });
  }
}
module.exports = AdminController;

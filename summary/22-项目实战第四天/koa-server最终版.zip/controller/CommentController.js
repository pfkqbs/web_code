const CommentModel = require("../models/CommentModel");
const { commentValidator } = require("../validators/comment");
const res = require("../core/helper");
const ReplyModel = require("../models/ReplyModel");
class CommentController {
  static async createComment(ctx, next) {
    // 校验参数
    commentValidator(ctx);
    const { target_id } = ctx.request.body;
    // 查询一下文章列表是否有 target_id
    // ArticleModel.find().where({_id:target_id})
    const data = await CommentModel.create(ctx.request.body);
    ctx.body = res.json(data);
  }
  // 获取评论列表
  static async getCommentList(ctx, next) {
    const { pageIndex = 1, pageSize = 10 } = ctx.query;
    // 获取总数
    const totalSize = await CommentModel.find().countDocuments();
    const commentList = await CommentModel.find()
      .skip(parseInt(pageIndex - 1) * pageSize)
      .sort([["_id", -1]])
      .limit(parseInt(pageSize));
    const data = {
      content: commentList,
      currentPage: parseInt(pageIndex),
      pageSize: parseInt(pageSize),
      totalSize,
    };
    ctx.body = res.json(data);
  }
  // 获取该评论的详情
  static async getCommentDetailById(ctx, next) {
    const _id = ctx.params._id;
    const commentDetail = await CommentModel.findById({ _id }).lean();
    if (!commentDetail) {
      throw new global.errs.NotFound("没有找到相关评论信息");
    }
    // todo: 获取该评论的回复列表
    const replyList = [];
    const data = {
      commentDetail,
      replyList,
    };
    ctx.status = 200;
    ctx.body = res.json(data);
  }
  // 更新评论
  static async updateCommentById(ctx, next) {
    const _id = ctx.params._id;
    const comment = await CommentModel.findByIdAndUpdate(
      { _id },
      ctx.request.body
    );
    if (!comment) {
      throw new global.errs.NotFound("没有找到相关评论");
    }
    ctx.body = res.success("更新评论成功");
  }
  // 删除评论
  static async deleteCommentById(ctx, next) {
    const _id = ctx.params._id;
    const comment = await CommentModel.findOneAndDelete({ _id });
    if (!comment) {
      throw new global.errs.NotFound("没有找到相关评论");
    }
    ctx.body = res.success("删除评论成功");
  }
  // 获取目标评论
  static async getTargetComment(ctx, next) {
    const commentList = await CommentController.targetComment(ctx.query);
    ctx.status = 200;
    ctx.body = res.json(commentList);
  }
  // 获取目标评论
  static async targetComment(params = {}) {
    // target_id: 文章id
    const { target_id, pageIndex = 1, pageSize = 4 } = params;
    // 评论总数量
    const totalSize = await CommentModel.find({
      target_id,
    }).countDocuments();
    // 获取所有的评论
    const commentList = await CommentModel.find({
      target_id,
    })
      .skip(parseInt(pageIndex - 1) * parseInt(pageSize))
      .limit(parseInt(pageSize))
      .sort({
        _id: -1,
      })
      .lean();
    //  2.获取评论下回复列表
    // Promise.all()
    let newCommentList = await Promise.all(
      commentList.map(async (comment) => {
        let replyList = await ReplyModel.find({
          comment_id: comment._id,
        });
        comment.replyList = replyList;
        return comment;
      })
    );

    return {
      data: newCommentList,
      pageIndex: parseInt(pageIndex),
      pageSize: parseInt(pageSize),
      totalSize,
    };
  }
}
module.exports = CommentController;

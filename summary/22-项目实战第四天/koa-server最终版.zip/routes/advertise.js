const AdvertiseController = require("../controller/AdvertiseController");
const jwtAuth = require("koa-jwt");
module.exports = (router) => {
  // 创建广告
  router.post(
    "/advertise",
    jwtAuth({ secret: global.config.security.secretKey }),
    AdvertiseController.createAdvertise
  );
  // 获取广告列表
  router.get("/advertise", AdvertiseController.getAdvertiseList);
  // 加权限
  router.get(
    "/advertise/:_id",
    jwtAuth({ secret: global.config.security.secretKey }),
    AdvertiseController.getAdvertiseDetailById
  );
  // 更新
  router.put(
    "/advertise/:_id",
    jwtAuth({ secret: global.config.security.secretKey }),
    AdvertiseController.updateAdvertiseById
  );
  // 删除
  router.delete(
    "/advertise/:_id",
    jwtAuth({ secret: global.config.security.secretKey }),
    AdvertiseController.deleteAdvertiseById
  );
};

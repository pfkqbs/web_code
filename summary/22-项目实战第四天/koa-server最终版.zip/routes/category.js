const CategoryController = require("../controller/CategoryController");
const jwtAuth = require("koa-jwt");
module.exports = (router) => {
  // 创建分类
  router.post("/category", CategoryController.create);
  // 获取分类列表
  router.get("/category", CategoryController.getCategoryList);
  // 更新分类
  router.put("/category/:_id", CategoryController.updateCategoryById);
  // 删除分类
  router.delete("/category/:_id", CategoryController.deleteCategoryById);
};

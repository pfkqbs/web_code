const ArticleController = require("../controller/ArticleController");
const jwtAuth = require("koa-jwt");
const upload = require("../middlewares/upload");
module.exports = (router) => {
  // 创建文章
  router.post(
    "/article",
    jwtAuth({ secret: global.config.security.secretKey }),
    ArticleController.createArticle
  );
  //   获取文章
  router.get("/article", ArticleController.getArticleList);
  //    更新文章
  router.put("/article/:_id", ArticleController.updateArticeleById);
  // 删除文章
  router.delete("/article/:_id", ArticleController.deleteArticelById);
  //   获取文章详情
  router.get("/article/:_id", ArticleController.getArticleDetailById);
  // 图片上传
  router.post(
    "/upload",
    upload.single("avatar"),
    ArticleController.uploadCoverImg
  );
};

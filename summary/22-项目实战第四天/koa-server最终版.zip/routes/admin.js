const AdminController = require("../controller/AdminController");
const jwtAuth = require("koa-jwt");
module.exports = (router) => {
  //  resetFul api
  // 注册用户
  router.post("/admin/register", AdminController.register);
  // 登录
  router.post("/admin/login", AdminController.login);

  router.get(
    "/admin/user/info",
    jwtAuth({ secret: global.config.security.secretKey }),
    AdminController.getUserInfo
  );
};

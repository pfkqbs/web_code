const AdminModel = require("../models/AdminModel");
const bcrypt = require("bcrypt");
const { generateToken } = require("../extend/util");
class LoginManager {
  static async adminLogin({ nickname, password }) {
    // 验证用户名和密码是否正确
    const user = await AdminModel.findOne({ nickname });
    if (!user) {
      throw new global.errs.AuthFailed("用户名不存在");
    }
    const correct = bcrypt.compareSync(password, user.password);
    if (!correct) {
      throw new global.error.AuthFailed("密码不存在");
    }

    // 颁发令牌 生成token
    const token = generateToken(user._id);
    return {
      nickname,
      token,
    };
  }
}
module.exports = LoginManager;

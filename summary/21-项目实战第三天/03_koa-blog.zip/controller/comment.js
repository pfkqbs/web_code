const CommentModel = require("../models/CommentModel");
const ReplyModel = require("../models/ReplyModel");
const { commentValidator } = require("../validators/comment");
class CommentController {
  static async createComment(ctx, next) {
    // 校验参数
    commentValidator(ctx);
    await CommentModel.create(ctx.request.body);
    ctx.body = global.res.success(null, "创建评论成功");
  }
  static async getCommentList(ctx, next) {
    const { pageIndex = 1, pageSize = 10 } = ctx.query;
    console.log(Number(pageIndex - 1) * Number(pageSize));
    const total = await CommentModel.find().countDocuments();
    const commentList = await CommentModel.find()
      .skip(Number(pageIndex - 1) * Number(pageSize))
      .limit(Number(pageSize))
      .sort({ _id: -1 });
    if (!commentList) {
      throw new global.errs.NoExisting("评论列表获取失败");
    }
    ctx.body = global.res.success({
      content: commentList,
      total,
      pageIndex,
      pageSize,
    });
  }
  static async getCommentDetailById(ctx, next) {
    const _id = ctx.params._id;
    const commentDetail = await CommentModel.findById({ _id }).lean();
    if (!commentDetail) {
      throw new global.errs.NoExisting(
        "没有找到相关评论信息，请检查params参数"
      );
    }
    // todo:获取该评论的回复数据

    ctx.body = global.res.success({ commentDetail, replayList: [] });
  }
  // 更新评论
  static async updateCommentById(ctx, next) {
    const _id = ctx.params._id;
    const comment = await CommentModel.findByIdAndUpdate(
      { _id },
      ctx.request.body
    );
    if (!comment) {
      throw new global.errs.NoExisting(
        "没有找到相关评论信息，请检查params参数"
      );
    }
    ctx.body = global.res.success(null, "更新评论成功");
  }
  static async deleteCommentById(ctx, next) {
    const _id = ctx.params._id;
    const comment = await CommentModel.findByIdAndDelete({ _id });
    if (!comment) {
      throw new global.errs.NoExisting(
        "没有找到相关评论信息，请检查params参数"
      );
    }
    // 同步删除回复表的数据 （主从表）
    // 1、同步删除的方法  2、逻辑去手动
    ctx.body = global.res.success(null, "删除评论成功");
  }
  static async targetCommentList({ article_id }) {
    let commentList = await CommentModel.find({ article_id }).lean();

    // Promise.all
    let newCommentList = await Promise.all(
      commentList.map(async (comment) => {
        const replyList = await ReplyModel.find({
          comment_id: comment._id,
        }).lean();
        console.log(replyList)
        comment.replyList = replyList;
        return comment;
      })
    );

    return { commentList: newCommentList };
  }
}
module.exports = CommentController;

const CategoryModel = require("../models/CategoryModel");
const { categoryValidator } = require("../validators/category");
class CategoryController {
  // 创建分类
  static async createCategory(ctx, next) {
    // 校验参数
    categoryValidator(ctx);
    const { name, keyword } = ctx.request.body;
    const hasCategory = await CategoryModel.findOne({ name });
    console.log(hasCategory);
    if (hasCategory) {
      throw new global.errs.Existing("分类已存在");
    }
    const category = await CategoryModel.create({ name, keyword });
    ctx.status = 200;
    ctx.body = global.res.success(category);
  }
  static async getCategoryList(ctx, next) {
    const { pageIndex = 1, pageSize = 10, name, keyword } = ctx.query;
    const total = await CategoryModel.find().countDocuments();
    const categoryList = await CategoryModel.find()
      .where()
      .skip(Number(pageIndex - 1) * Number(pageSize))
      .limit(Number(pageSize))
      .sort({ _id: -1 });
    ctx.body = global.res.success({
      content: categoryList,
      total,
      pageIndex: Number(pageIndex),
      pageSize: Number(pageSize),
    });
  }
  static async updateCategory(ctx, next) {
    const _id = ctx.params._id;
    const { name, keyword } = ctx.request.body;
    // category 为通过_id获取的已有分类数据
    const category = await CategoryModel.findByIdAndUpdate(
      { _id },
      { name, keyword }
    );
    if (!category) {
      throw new global.errs.NoExsiting("没有找到相关分类");
    }
    ctx.body = global.res.success(null, "更新分类成功");
  }
  // 删除分类
  static async deleteCategory(ctx, next) {
    const _id = ctx.params._id;
    const category = await CategoryModel.findByIdAndDelete({ _id });
    // Todo: 删除分类后 要同步删除文章
    if (!category) {
      throw new global.errs.NoExisting("没有找到相关分类");
    }
    ctx.body = global.res.success(null, "删除分类成功");
  }
}
module.exports = CategoryController;

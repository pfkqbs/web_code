const ReplyModel = require("../models/ReplyModel");
const CommentModel = require("../models/CommentModel");
const { replyValidator } = require("../validators/reply");
class ReplyController {
  // 创建回复
  static async createReply(ctx, next) {
    replyValidator(ctx);
    const { comment_id } = ctx.request.body;
    const comment = await CommentModel.findById({ _id: comment_id });
    if (!comment) {
      throw new global.errs.NoExisting("没有找到相关评论");
    }
    const reply = await ReplyModel.create(ctx.request.body);
    // 要想调用get方法 必须将数据转成json
    reply.toJSON({ getters: true });
    ctx.body = global.res.success(reply);
  }
  // 获取该评论下的回复列表
  static async getReplyList(ctx, next) {
    const comment_id = ctx.query.comment_id;
    if (!comment_id) {
      throw new global.errs.NoExsiting("请检查query查询参数");
    }
    const replyList = await ReplyModel.find({ comment_id }).sort({ _id: -1 });
    ctx.body = global.res.success(replyList);
  }
  // 获取该评论下的回放详情内容
  static async getReplyDetailById(ctx, next) {
    const _id = ctx.params._id;
    const replyDetail = await ReplyModel.findById({ _id });
    if (!replyDetail) {
      throw new global.errs.NoExisting(
        "没有找到相关评论的回复详情信息，请检查params参数"
      );
    }
    ctx.body = global.res.success(replyDetail);
  }

  static async updateReplayById(ctx, next) {
    const _id = ctx.params._id;
    const replay = await ReplyModel.findByIdAndUpdate(
      { _id },
      ctx.request.body
    );
    if (!replay) {
      throw new global.errs.NoExisting("没有找到相关信息，请检查params参数");
    }
    ctx.body = global.res.success(null, "更新回复内容成功");
  }

  static async deleteReplayById(ctx, next) {
    const _id = ctx.params._id;
    const replay = await ReplyModel.findByIdAndDelete({ _id });
    if (!replay) {
      throw new global.errs.NoExisting("没有找到相关信息，请检查params参数");
    }
    ctx.body = global.res.success(null, "删除回复内容成功");
  }
}
module.exports = ReplyController;

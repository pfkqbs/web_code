const ArticleModel = require("../models/ArticleModel");
const CommentController = require("./comment");
const CategoryModel = require("../models/CategoryModel");
const { articleValidator } = require("../validators/article");
class ArticleController {
  // 创建文章
  static async createArticle(ctx, next) {
    // 验证参数
    articleValidator(ctx);
    const { title, category_id } = ctx.request.body;
    console.log(category_id);
    const hasCartegory = await CategoryModel.findById({ _id: category_id });
    console.log(hasCartegory);
    if (!hasCartegory) {
      throw new global.errs.NoExisting("该分类不存在");
    }
    const hasArticle = await ArticleModel.findOne({ title });
    if (hasArticle) {
      throw new global.errs.Existing("文章已存在");
    }
    await ArticleModel.create(ctx.request.body);
    ctx.body = global.res.success(null, "创建文章成功");
  }
  // 获取文章列表
  static async getArticleList(ctx, next) {
    // 获取分类id 当前分页的页数，每页显示的内容数 关键字
    let {
      category_id = null,
      pageIndex = 1,
      pageSize = 10,
      keyword,
    } = ctx.query;
    // 是否存在分类id
    let filter = {};
    if (category_id) {
      filter.category_id = category_id;
    }
    // 转整型
    pageIndex = parseInt(pageIndex);
    pageSize = parseInt(pageSize);
    // 文章
    // const reg = new RegExp(keyword, 'i');//不区分大小写
    // 获取文章总数量
    const total = await ArticleModel.find().countDocuments();
    // 获取分页之后的文章列表
    const articleList = await ArticleModel.find()
      .where(filter)
      .skip((pageIndex - 1) * pageSize)
      .limit(pageSize)
      .or([
        // 模糊查询  query.or([{条件1},{条件2}])
        {
          keyword: {
            $regex: new RegExp(keyword, "i"),
          },
        },
      ])
      .sort({ _id: -1 }) //倒序
      .populate("category_id"); //连表查询
    const data = {
      content: articleList,
      total,
      pageIndex,
      pageSize,
    };
    ctx.body = global.res.success(data);
  }
  // 更新文章
  static async updateArticle(ctx, next) {
    const _id = ctx.params._id;
    let article = await ArticleModel.findByIdAndUpdate(
      { _id },
      ctx.request.body
    );
    if (!article) {
      throw new global.errs.NoExisting("没有找到相关文章");
    }
    ctx.body = global.res.success(null, "更新文章成功");
  }
  // 获取文章详情
  static async getArticleDetail(ctx, next) {
    const _id = ctx.params._id;
    console.log(_id);

    // 获取文章详情表
    const articleDetail = await ArticleModel.findById({ _id }).populate(
      "category_id"
    );
    // 更新文章浏览数
    await ArticleModel.findByIdAndUpdate(
      { _id },
      { browse: ++articleDetail.browse }
    );
    if (!articleDetail) {
      throw new global.errs.NoExisting("没有找到相关文章");
    }
    let { commentList } = await CommentController.targetCommentList({
      article_id: articleDetail._id,
    });
    const data = {
      articleDetail,
      commentList,
    };
    //
    ctx.body = global.res.success(data);
  }
  // 删除文章
  static async deleteArticle(ctx, next) {
    const _id = ctx.params._id;
    let article = await ArticleModel.findByIdAndDelete({ _id });
    if (!article) {
      throw new global.errs.NoExisting("没有找到相关文章");
    }
    ctx.status = 200;
    ctx.body = res.success("删除文章成功");
  }
}
module.exports = ArticleController;

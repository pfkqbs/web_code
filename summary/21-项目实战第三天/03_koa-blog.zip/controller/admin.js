const AdminModel = require("../models/AdminModel");
const { registerValidator, loginValidator } = require("../validators/admin");
const LoginManager = require("../services/login");
class AdminController {
  // 注册
  static async register(ctx, next) {
    // 参数校验
    registerValidator(ctx);
    // 处理业务
    const { nickname, password, password2 } = ctx.request.body;
    const currentUser = await AdminModel.findOne({ nickname });
    if (currentUser) {
      // 有重复的名字
      throw new global.errs.Existing("用户名已存在，请重新输入");
    }
    // 新建用户
    const user = await AdminModel.create({
      nickname,
      password,
    });
    ctx.body = global.res.success(user);

    // ctx.body = {
    //   code: 1,
    //   message: "注册成功",
    //   data: user,
    // };
  }
  // 登录
  static async login(ctx, next) {
    loginValidator(ctx);
    const { nickname, password } = ctx.request.body;
    const data = await LoginManager.adminLogin({ nickname, password });
    ctx.body = global.res.success(data, "登录成功");
  }

  // 获取用户的信息
  static async getUserInfo(ctx, next) {
    console.log(ctx.state.user.data);
    const _id = ctx.state.user.data;
    const userInfo = await AdminModel.findById({ _id });
    if (!userInfo) throw new global.errs.NoExisting("用户不存在");
    ctx.body = global.res.success(
      {
        _id,
        nickname: userInfo.nickname,
        age: 20,
        avatar: "http://www.jd.com/xiaomage.png",
      },
      "数据获取成功"
    );
  }
}

module.exports = AdminController;

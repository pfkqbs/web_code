const mongoose = require("mongoose");
// 对密码加盐处理
const bcrypt = require("bcrypt");
// 用户名 密码 （进行加密）
const adminSchema = new mongoose.Schema({
  nickname: {
    type: String,
    require: true,
  },
  password: {
    type: String,
    require: true,
    set(val) {
      // 加密生成
      const salt = bcrypt.genSaltSync(10);
      const pwd = bcrypt.hashSync(val, salt);
      return pwd;
    },
  },
});
// 定义model
const AdminModel = mongoose.model("Admin", adminSchema);
module.exports = AdminModel;

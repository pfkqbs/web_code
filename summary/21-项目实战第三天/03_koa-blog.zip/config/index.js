module.exports = {
  port: 5001,
  db: {
    port: 27017,
    host: "127.0.0.1",
    dbName: "koa2Blog", // 数据库名称
  },
  // 签证配置
  security: {
    secretKey: "secretKey",
    expiresIn: Math.floor(Date.now() / 1000) + 60 * 60 * 24,
  },
};

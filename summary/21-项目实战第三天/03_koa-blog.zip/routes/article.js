const ArticleController = require("../controller/article");
const jwtAuth = require("koa-jwt");
module.exports = (router) => {
  // 创建文章
  router.post(
    "/article",
    // jwtAuth({ secret: global.config.security.secretKey }),
    ArticleController.createArticle
  );
  router.get(
    "/article",
    // jwtAuth({ secret: global.config.security.secretKey }),
    ArticleController.getArticleList
  );
  router.put(
    "/article/:_id",
    // jwtAuth({ secret: global.config.security.secretKey }),
    ArticleController.updateArticle
  );
  // 获取文章详情
  router.get("/article/:_id", ArticleController.getArticleDetail);
  // 删除文章
  router.delete(
    "/article/:_id",
    // jwtAuth({ secret: global.config.security.secretKey }),
    ArticleController.deleteArticle
  );
};

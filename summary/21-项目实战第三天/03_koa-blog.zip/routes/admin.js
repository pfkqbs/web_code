const AdminController = require("../controller/admin");
const jwtAuth = require("koa-jwt");
module.exports = (router) => {
  // 控制器 controller
  router.post("/admin/register", AdminController.register);
  router.post("/admin/login", AdminController.login);
  router.get(
    "/admin/userInfo",
    jwtAuth({ secret: global.config.security.secretKey }),
    AdminController.getUserInfo
  );
};

const AdvertiseController = require("../controller/advertise");
module.exports = (router) => {
  // 创建广告
  router.post("/advertise", AdvertiseController.createAdvertise);
  // 获取广告列表
  router.get("/advertise", AdvertiseController.getAdvertiseList);
  // 获取广告详情
  router.get("/advertise/:_id", AdvertiseController.getAdvertiseDetailById);
  // 更新广告
  router.put(
    "/advertise/:_id",
    // jwtAuth({
    //   secret: global.config.security.secretKey,
    // }),
    AdvertiseController.updateAdvertiseById
  );
  // 删除广告
  router.delete(
    "/advertise/:_id",
    // jwtAuth({
    //   secret: global.config.security.secretKey,
    // }),
    AdvertiseController.deleteAdvertiseById
  );
};

const CategoryController = require("../controller/category");
const jwtAuth = require("koa-jwt");
module.exports = (router) => {
  const secretKey = global.config.security.secretKey;
  // 创建分类
  router.post(
    "/category",
    // jwtAuth({ secret: secretKey }),
    CategoryController.createCategory
  );
  router.get(
    "/category",
    // jwtAuth({ secret: secretKey }),
    CategoryController.getCategoryList
  );
  router.put(
    "/category/:_id",
    // jwtAuth({ secret: secretKey }),
    CategoryController.updateCategory
  );
  router.delete(
    "/category/:_id",
    // jwtAuth({ secret: secretKey }),
    CategoryController.deleteCategory
  );
};

const CommentController = require("../controller/comment");
module.exports = (router) => {
  router.post("/comment", CommentController.createComment);
  //获取评论列表接口
  router.get("/comment", CommentController.getCommentList);
  // 获取评论详情
  router.get('/comment/:_id',CommentController.getCommentDetailById)
  // 更新评论
  router.put('/comment/:_id',CommentController.updateCommentById)
  // 删除评论 
   router.delete('/comment/:_id',CommentController.deleteCommentById)

};

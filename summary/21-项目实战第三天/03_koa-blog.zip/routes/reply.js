const ReplyController = require("../controller/reply");
module.exports = (router) => {
  // 创建回复
  router.post("/reply", ReplyController.createReply);
  // 获取评论的回复列表
  router.get("/reply", ReplyController.getReplyList);
  router.get("/reply/:_id", ReplyController.getReplyDetailById);
  // 更新
  router.put("/reply/:_id", ReplyController.updateReplayById);

  // 删除
  router.delete("/reply/:_id", ReplyController.deleteReplayById);
};

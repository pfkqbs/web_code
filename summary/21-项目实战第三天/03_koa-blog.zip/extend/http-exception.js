class HttpException extends Error {
    constructor(message = '服务器异常', errorCode = 10000, code = 400) {
      super()
      this.errorCode = errorCode
      this.code = code
      this.message = message
    }
  }
  //参数错误
  class ParameterException extends HttpException {
    constructor(message, errorCode) {
      super()
      this.code = 400
      this.message = message || '参数错误'
      this.errorCode = errorCode || 10000
    }
  }
  //认证失败
  class AuthFailed extends HttpException {
    constructor(message, errorCode) {
      super()
      this.code = 401
      this.message = message || '授权失败'
      this.errorCode = errorCode || 10004
    }
  }
  //404
  class NotFound extends HttpException {
    constructor(message, errorCode) {
      super()
      this.code = 404
      this.message = message || '404找不到'
      this.errorCode = errorCode || 10005
    }
  }
  //禁止访问
  class Forbidden extends HttpException {
    constructor(message, errorCode) {
      super()
      this.code = 403
      this.message = message || '禁止访问'
      this.errorCode = errorCode || 10006
    }
  }
  //xxx已存在
  class Existing extends HttpException {
    constructor(message, errorCode) {
      super()
      this.code = 412
      this.message = message || '已存在'
      this.errorCode = errorCode || 10006
    }
  }
  class NoExisting extends HttpException {
    constructor(message, errorCode) {
      super()
      this.code = 413
      this.message = message || '不存在'
      this.errorCode = errorCode || 10006
    }
  }
  
  module.exports = {
    HttpException,
    ParameterException,
    AuthFailed,
    NotFound,
    Forbidden,
    Existing,
    NoExisting
  }
  
  
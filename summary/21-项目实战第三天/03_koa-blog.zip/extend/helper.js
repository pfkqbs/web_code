class Resolve {
  success(data, msg = "success", code = 1) {
    return {
      msg,
      code,
      data: data || null,
    };
  }
}
const res = new Resolve();
module.exports = res;

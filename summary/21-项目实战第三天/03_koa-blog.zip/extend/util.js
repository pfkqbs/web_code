// 颁布令牌
const jwt = require("jsonwebtoken");
function generateToken(_id) {
  const { secretKey, expiresIn } = global.config.security;
  return jwt.sign(
    {
      data: _id,
      exp: expiresIn,
    },
    secretKey
  );
}

module.exports = {
  generateToken,
};

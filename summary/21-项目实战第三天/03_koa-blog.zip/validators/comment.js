function commentValidator(ctx) {
    ctx.validateBody('nickname')
      .required('评论人名字 nickname不能为空')
      .isString()
      .trim()
    ctx.validateBody('content')
      .required('评论内容 content不能为空')
      .isString()
      .trim()
    ctx.validateBody('article_id')
      .required('文章 id不能为空')
      .isString()
      .trim()
  }
  module.exports = {
    commentValidator
  }
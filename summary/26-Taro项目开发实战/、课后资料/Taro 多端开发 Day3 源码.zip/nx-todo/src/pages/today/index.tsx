import React from "react";
import { View, Text } from "@tarojs/components";
import "./index.scss";

const Today: React.FC = () => {
  return (
    <View>
      <Text>Today</Text>
    </View>
  );
};

export default Today;

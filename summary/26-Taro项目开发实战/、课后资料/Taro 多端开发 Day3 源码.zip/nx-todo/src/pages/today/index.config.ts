export default definePageConfig({
  navigationBarTitleText: '今天'
})

import React, { useCallback, useState } from "react";
import { View, Text, Button, CoverView } from "@tarojs/components";

const Modal = () => {
  const [open, setOpen] = useState(false);
  const handleOpen = useCallback(() => {
    setOpen(true);
  }, []);
  const handleClose = useCallback(() => {
    setOpen(false);
  }, []);
  return (
    <View>
      <Button onClick={handleOpen}>打开 Modal</Button>
      {/* {open && (
        <View>
          <Text>weapp modal</Text>
          <Text
            style={{
              backgroundColor: "#DDDDDD",
              width: "30px",
              height: "30px",
              borderRadius: "50%",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
            }}
            onClick={handleClose}
          >
            X
          </Text>
        </View>
      )} */}
      {open && (
        <CoverView
          style={{
            position: "fixed",
            left: 0,
            top: 0,
            width: "100%",
            height: "100%",
            backgroundColor: "rgba(0, 0, 0, 0.4)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: "80%",
              height: "80%",
              backgroundColor: "#FFFFFF",
            }}
          >
            <Text>h5 modal</Text>
            <Text
              style={{
                backgroundColor: "#DDDDDD",
                width: "30px",
                height: "30px",
                borderRadius: "50%",
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
              }}
              onClick={handleClose}
            >
              X
            </Text>
          </View>
        </CoverView>
      )}
    </View>
  );
};

export default Modal;

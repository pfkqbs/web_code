<template>
  <view class="index">
    <view>
      <img src="" alt="" />
    </view>
    {{ msg }}
    <view class="btn">
      <nut-button type="primary" @click="handleClick('text', msg2, true)"
        >点我</nut-button
      >
    </view>
    <!-- <nut-toast :msg="msg" v-model:visible="show" :type="type" :cover="cover" /> -->
    <!-- <nut-popup
      :style="{ height: '20%', background: 'pink' }"
      position="bottom"
      v-model:visible="show"
      >{{ msg }}</nut-popup
    > -->
    <nut-fixednav
      :position="{ top: '70px' }"
      v-model:visible="show"
      :nav-list="navList"
    />
  </view>
</template>

<script>
import { reactive, toRefs } from "vue";
export default {
  name: "Index",
  components: {},
  setup() {
    const state = reactive({
      msg: "欢迎使用 NutUI3.0 开发小程序",
      msg2: "你成功了～",
      type: "text",
      show: false,
      cover: false,
    });
    const navList = reactive([
      {
        id: 1,
        text: "首页",
        icon:
          "https://img11.360buyimg.com/imagetools/jfs/t1/117646/2/11112/1297/5ef83e95E81d77f05/daf8e3b1c81e3c98.png",
      },
      {
        id: 2,
        text: "分类",
        icon:
          "https://img12.360buyimg.com/imagetools/jfs/t1/119490/8/9568/1798/5ef83e95E968c69a6/dd029326f7d5042e.png",
      },
    ]);

    const handleClick = (type, msg, cover = false) => {
      state.show = true;
      state.msg2 = msg;
      state.type = type;
      state.cover = cover;
    };

    return {
      ...toRefs(state),
      navList,
      handleClick,
    };
  },
};
</script>

<style lang="scss">
.index {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
}
</style>

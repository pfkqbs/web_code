const Router = require('@koa/router')
const router = new Router()

router.get('/', async (ctx, next) => {
  console.log(ctx.state.count)
  //   ctx.body = 'hello router'

  ctx.redirect('/list')
})
router.get('/list', async (ctx, next) => {
  const data = {
    title: '学习hbs',
    subTitle: 'hello hbs',
    username: '小马哥',
    htmlStr: '<em>这是一个html</em>',
    isShow: true,
    users: [
      {
        name: '小黄',
        age: 20,
      },
      {
        name: '小红',
        age: 18,
      },
    ],
    a: true,
    b: true,
    arr:['a','b']
  }
  await ctx.render('index', data)
})
router.post('/login', async (ctx, next) => {
  // 必须通过koa-bodyparser解析
  const body = ctx.request.body
  ctx.body = { ok: 200 }
})
router.get('/login', async (ctx, next) => {
  ctx.body = '<h3>已登录</h3>'
})

module.exports = router

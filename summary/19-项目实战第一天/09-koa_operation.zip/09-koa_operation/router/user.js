const Router = require('@koa/router')
const jwt = require('jsonwebtoken')
const jwtAuth = require('koa-jwt')
const multer = require('koa-multer')
const bouncer = require('koa-bouncer')
const catpcha = require('trek-captcha')
// 配置 磁盘存储
const storage = multer.diskStorage({
  // 文件保存路径
  destination: function (req, file, cb) {
    cb(null, 'public/images')
  },
  // 修改文件名称
  filename: function (req, file, cb) {
    // 1.png
    const filterFormat = file.originalname.split('.')
    cb(null, Date.now() + '.' + filterFormat[filterFormat.length - 1])
  },
})
const upload = multer({ storage })

const router = new Router()
router.prefix('/user')
router.get('/', async (ctx, next) => {
  ctx.body = '用户页面'
})
router.post('/login', async (ctx, next) => {
  const { user } = ctx.request.body
  //   签名, 经过MD5 UUID
  ctx.session.userInfo = user
  ctx.body = {
    code: 200,
    message: '登录成功',
  }
})
router.post('/logout', async (ctx, next) => {
  if (ctx.session.userInfo) {
    delete ctx.session.userInfo
  }
  ctx.body = {
    code: 200,
    message: '退出成功',
  }
})

router.get('/getUser', require('../middleware/auth.js'), async (ctx, next) => {
  ctx.body = {
    code: 200,
    message: '获取数据成功',
    userInfo: ctx.session.userInfo,
  }
})

const secret = 'this is a scret'

router.post('/login-token', async (ctx, next) => {
  const { body } = ctx.request
  const userinfo = body.user
  ctx.body = {
    ok: 1,
    message: '登录成功',
    user: userinfo,
    // 使用jwt模块签名一个令牌,生成 token 返回给客户端
    token: jwt.sign(
      {
        data: userinfo, //由于签名不是加密,令牌不要存放敏感数据
        exp: Math.floor(Date.now() / 1000) + 60 * 60, //过期时间一分钟
      },
      secret
    ),
  }
})
router.get(
  '/getUser-token',
  jwtAuth({
    //对传入令牌进行校验
    secret,
  }),
  async (ctx, next) => {
    ctx.body = {
      message: '获取数据成功',
      userinfo: ctx.state.user.data,
    }
  }
)
router.post('/upload', upload.single('avatar'), (ctx, next) => {
  // file 是avatar文件的信息
  // ctx.req.body 文本域的数据 如果存在
  console.log(ctx.req.file.filename)
  ctx.body = {
    ok: 1,
  }
})

// 表单验证
router.post('/', async (ctx, next) => {
  console.log(ctx.request.body)
  // ctx.request.body  {uname,pwd1,pwd2}
  try {
    /* 
    ctx.validateBody('username')
    .required('Username is required')
    .isString()
    .trim()
    .isLength(3, 15, 'Username must be 3-15 chars');
    
    */
    ctx
      .validateBody('uname')
      .required('用户名是必须的')
      .isString()
      .trim()
      .isLength(4, 8, '用户名必须是4~8位')
    ctx
      .validateBody('email')
      .optional()
      .isString()
      .trim()
      .isEmail('非法的邮箱格式')
    ctx
      .validateBody('pwd1')
      .required('密码是必填项')
      .isString()
      .trim()
      .isLength(6, 16, '密码必须是6~16位')
    ctx
      .validateBody('pwd2')
      .required('密码是必填项')
      .isString()
      .trim()
      .eq(ctx.vals.pwd1, '两次密码不一致')

    console.log(ctx.vals)
    ctx.body = {
      code: 1,
    }
  } catch (error) {
    // 校验异常
    if (error instanceof bouncer.ValidationError) {
      console.log(error)
      ctx.status = 400
      ctx.body = {
        code: 400,
        message: '校验失败:' + error.message,
      }
      return
    }
    throw error
  }
})
// 图形验证码
router.get('/captcha', async (ctx, next) => {
  const { token, buffer } = await catpcha({ size: 4 });
  // ctx.state.bufferToken = token
    //token的作用 前端输入完验证码与此时的token做对比
  ctx.body = buffer;
})


module.exports = router

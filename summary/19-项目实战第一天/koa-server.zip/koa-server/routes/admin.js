const AdminController = require("../controller/AdminController");
module.exports = (router) => {
  //  resetFul api
  // 路由前缀
  router.prefix("/api/v1");
  // 注册用户
  router.post("/admin/register", AdminController.register);
  // 登录
  router.post('/admin/login',AdminController.login)
};

const AdminModel = require("../models/AdminModel");
const bcypt = require("bcrypt");
const {generateToken} = require('../core/util')
class LoginManager {
  static async adminLogin({ nickname, password }) {
    // 验证用户名和密码是否正确
    const user = await AdminModel.findOne({ nickname });
    console.log(user)
    if (!user) {
      throw new global.errs.AuthFailed("用户名不存在或者密码不正确");
    }
    const correct = bcypt.compareSync(password, user.password);
    if (!correct) {
      throw new global.errs.AuthFailed("密码不正确");
    }
    // 用户名和密码是正确的
    // 颁发令牌  生成token
    const token = generateToken(user._id)
    return {
       nickname: user.nickname,
       token 
    }
  }
}
module.exports = LoginManager;

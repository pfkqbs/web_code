const AdminModel = require("../models/AdminModel");
const { registerValidator, loginValidator } = require("../validators/admin");
const LoginManager = require("../services/login");
class AdminController {
  // 注册
  static async register(ctx, next) {
    //   参数校验
    registerValidator(ctx);
    //   nickname,password,password2
    const { nickname, password2 } = ctx.request.body;
    const currentUser = await AdminModel.findOne({ nickname });
    if (currentUser) {
      throw new global.errs.Existing("用户已存在", 900);
    }
    const user = await AdminModel.create({
      nickname,
      password: password2,
    });
    ctx.status = 200;
    ctx.body = {
      code: 200,
      msg: "success",
      data: user,
      errorCode: 0,
    };
  }
  // 登录
  static async login(ctx, next) {
    loginValidator(ctx);
    /*
     */
    const { nickname, password } = ctx.request.body;
    console.log(nickname,password)
    /* 
    {
       nickname: user.nickname,
       token 
    }
    
    */
    const user = await LoginManager.adminLogin({ nickname, password });

    if (!user) {
      throw new global.errs.NotFound("用户不存在");
    }
    ctx.body = {
      code: 200,
      message: "登录成功",
      data: user,
    };
  }
}
module.exports = AdminController;

const Koa = require('koa')
const onerror = require('koa-onerror')
// const logger = require('koa-logger')
const { accessLogger, logger } = require('./logger')
const app = new Koa()

onerror(app)
app.use(accessLogger())
// app.use(logger())
// 错误处理中间
// app.use(async (ctx, next) => {
//   try {
//     await next()
//   } catch (error) {
//     const { status, data, message } = error
//     // switch
//     ctx.status = status || 500
//     ctx.type = 'json'
//     ctx.body = { code: status, message, data }

//     // 手动触发全局的错误函数
//     ctx.app.emit('error', error, ctx)
//   }
// })
// app.use((ctx) => {
//   // foo();
//   ctx.body = fs.createReadStream('not exist')
// })

// koa的中间件
app.use(async (ctx, next) => {
  // ctx.throw()相当于是一个中间件
  ctx.throw(401, '未授权', { data: '你瞅瞅' })
  //   ctx.body = '小马哥' //设置响应体`
  /* 
  等价
  const err = new Error('未授权');
err.status = 401;
err.expose = true;
throw err;
  */
})

app.use(async (ctx) => {
  ctx.body = '错误处理中间件'
})
// 全局的事件监听器
app.on('error', (err) => {
  //   console.log('全局错误处理:', err.message, err.status, err.data)
  logger.error(err)
})

app.listen(5000, () => {
  console.log('5000端口被监听了~~')
})

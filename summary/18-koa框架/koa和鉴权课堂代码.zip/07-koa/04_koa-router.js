const Koa = require('koa')
const onerror = require('koa-onerror')
// const logger = require('koa-logger')
const { accessLogger, logger } = require('./logger')
const static = require('koa-static')
const bodyParser = require('koa-bodyparser')
const hbs = require('koa-hbs')
const routerIndex = require('./router/index')
const helpers = require('./utils/helpers')

const app = new Koa()

onerror(app)
app.use(static(__dirname, 'public'))
app.use(bodyParser())
// app.use(accessLogger())

// 注册模板引擎的中间件
app.use(
  hbs.middleware({
    viewPath: __dirname + '/views', //视图的根目录
    defaultLayout: 'layout',
    partialsPath: __dirname + '/views/partials',
    disableCache: true, //开发阶段不缓存
  })
)

app.use(async (ctx, next) => {
  // 通过state命名空间的来设置共享的数据
  // 一旦设置完成,所有的路由器都能使用此数据
  ctx.state.count = 10
  await next()
})

// 注册路由
app.use(routerIndex.routes())
app.use(routerIndex.allowedMethods())

// 全局的事件监听器
app.on('error', (err) => {
  //   console.log('全局错误处理:', err.message, err.status, err.data)
  logger.error(err)
})

app.listen(5000, () => {
  console.log('5000端口被监听了~~')
})

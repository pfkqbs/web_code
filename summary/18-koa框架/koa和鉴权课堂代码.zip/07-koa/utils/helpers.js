const hbs = require('koa-hbs')
const helpers = require('handlebars-helpers')
helpers.comparison({ handlebars: hbs.handlebars })

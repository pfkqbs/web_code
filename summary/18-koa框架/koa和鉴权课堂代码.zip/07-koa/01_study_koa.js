const Koa = require('koa')
const app = new Koa()
app.use(async (ctx, next) => {
  // 对请求做处理
  console.log('老弟来了~~')
  await next() // 分割线
  const rt = ctx.response.get('X-Response-Time')
  console.log(`${ctx.method} ${ctx.url} - ${rt}`)
  console.log('老弟离开了~~')
})

app.use(async (ctx, next) => {
  const start = Date.now()
  console.log('嗯,我来了')
  await next()
  console.log('嗯,我走了')
  const ms = Date.now() - start
  ctx.set('X-Response-Time', `${ms}ms`)
})

// koa的中间件
app.use(async (ctx, next) => {
  console.log('吃完饭,准备走了')
  ctx.body = '小马哥' //设置响应体`
})



app.listen(5000, () => {
  console.log('5000端口被监听了~~')
})

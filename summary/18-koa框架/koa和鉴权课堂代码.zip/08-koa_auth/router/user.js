const Router = require('@koa/router')
const jwt = require('jsonwebtoken');
const jwtAuth = require('koa-jwt')
const router = new Router()
router.prefix('/user')
router.get('/', async (ctx, next) => {
  ctx.body = '用户页面'
})
router.post('/login', async (ctx, next) => {
  const { user } = ctx.request.body
  //   签名, 经过MD5 UUID
  ctx.session.userInfo = user
  ctx.body = {
    code: 200,
    message: '登录成功',
  }
})
router.post('/logout', async (ctx, next) => {
  if (ctx.session.userInfo) {
    delete ctx.session.userInfo
  }
  ctx.body = {
    code: 200,
    message: '退出成功',
  }
})

router.get('/getUser', require('../middleware/auth.js'), async (ctx, next) => {
  ctx.body = {
    code: 200,
    message: '获取数据成功',
    userInfo: ctx.session.userInfo,
  }
})


const secret = 'this is a scret';

router.post('/login-token', async (ctx, next) => {
  const { body } = ctx.request;
  const userinfo = body.user;
  ctx.body = {
    ok: 1,
    message: '登录成功',
    user: userinfo,
    // 使用jwt模块签名一个令牌,生成 token 返回给客户端
    token: jwt.sign(
      {
        data: userinfo, //由于签名不是加密,令牌不要存放敏感数据
        exp: Math.floor(Date.now() / 1000) + 60 * 60 //过期时间一分钟
      }, secret
    )
  }
})
router.get('/getUser-token', jwtAuth({ //对传入令牌进行校验
  secret
}), async (ctx, next) => {
  ctx.body = {
    message: '获取数据成功',
    userinfo: ctx.state.user.data
  }
})

module.exports = router

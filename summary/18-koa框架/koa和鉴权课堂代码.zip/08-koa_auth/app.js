// 引入
const Koa = require('koa')
// 实例化app
const app = new Koa();
const bodyParser = require('koa-bodyparser');
const static = require('koa-static');
const hbs = require("koa-hbs");
const session = require("koa-session");
// const redis = require('redis');
// const client = redis.createClient(6379, 'localhost');

// cnpm i koa-session -S

// 1.大家安装redis 自行安装
// 2.redis-server
// 3.redis koa-redis
// 导入路由
const routerIndex = require('./router');
const userIndex = require('./router/user');

// // 注册koa-bouncer,为了给ctx提供一些帮助方法
// const bouncer = require('koa-bouncer');
// app.use(bouncer.middleware());



// keys作用：用来对cookie进行签名
app.keys = ['session secret', 'anthor secret']

// localhost:3000/

app.use(async (ctx, next) => {
  // 从数据库获取模型对象  find() 查找相应的数据 通过state命名空间来设置共享的数据
  // 一旦设置好，所有的路由器中都能使用此数据
  ctx.state.navList = {
    a: 1
  }
  await next();
})

app.use(bodyParser());

// 注册模板引擎的中间件
app.use(hbs.middleware({
  viewPath: __dirname + '/views',//视图根目录
  defaultLayout: "layout",
  partialsPath: __dirname + '/views/partials',
  disableCache: true, //开发阶段不缓存

}))

// src='/images/1.png'

// 设置静态资源服务器目录
app.use(static(__dirname + '/public'));
const SESSON_CONFIG = {
  key: 'xiaomage:sess',//设置cookie的key名字
  maxAge: 86400000,//有效期，默认是一天
  httpOnly: true,//仅服务端修改
  signed: true,//签名cookie
}

app.use(session(SESSON_CONFIG, app));


// 这是测试代码
// app.use(async ctx => {
//   let n = ctx.session.count || 0;
//   ctx.session.count = ++n;
//   ctx.body = `第${n}次访问`;

//   // 获取redis中存储的数据
//   client.keys('*', (err, keys) => {
//     console.log(keys);
//     keys.forEach(key => {
//       client.get(key, (err, val) => {
//         console.log(val);
//       })
//     });
//   })

// })



// 注册路由
app.use(routerIndex.routes());
app.use(routerIndex.allowedMethods());

// 注册用户路由
app.use(userIndex.routes());
app.use(userIndex.allowedMethods());

// 监听
app.listen(5002, () => {
  console.log('5002 port listenging!!!')
})
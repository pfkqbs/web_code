const Koa = require('koa')
const app = new Koa()
const onerror = require('koa-onerror')
const static = require('koa-static')
const hbs = require('koa-hbs')
const { accessLogger, logger } = require('./logger')
const router = require('./router')
const helpers = require('handlebars-helpers')
helpers.comparison({ handlebars: hbs.handlebars })
// app.use(accessLogger())

// app.use(async (ctx, next) => {
//   // ctx.throw(401, '未授权', { data: '你看看来' })
//   ctx.body = '小马哥'
// })
onerror(app)
// 设置静态资源文件夹
app.use(static('public'))

// 设置模板引擎 hbs  vue
app.use(
  hbs.middleware({
    viewPath: __dirname + '/views', //视图的根目录
    defaultLayout: 'layout',
    partialsPath: __dirname + '/views/partials',
    disableCache: true, //开发阶段不缓存
  })
)

// app.use(async (ctx, next) => {
//   // 命名空间 通过state命名空间来设置共享的数据
//   ctx.state.name = 'kOA'
//   await next()
// })

// 注册路由
app.use(router.routes())
app.use(router.allowedMethods())

// 全局的事件监听器
app.on('error', (err) => {
  console.log('全局错误处理：', err.message, err.status, err.data)
  logger.error(err)
})

app.listen(5000, () => {
  console.log('5000端口被监听了')
})

const Router = require('@koa/router')
const router = new Router()
router.get('/', async (ctx, next) => {
  // console.log(ctx.state.name)
  ctx.redirect('/overview')
})

router.get('/overview', async (ctx, next) => {
  // 认为从数据库中获取
  const data = {
    title: '学习hbs',
    subTitle: '二级标题',
    isShow: true,
    array: ['a', 'b'],
    htmlStr: '<em>hello</em>',
    username: '小马哥',
    users: [
      {
        name: '张三',
        age: 20,
      },
      {
        name: '李四',
        age: 30,
      },
    ],
  }
  await ctx.render('index', data)
})

module.exports = router

const Koa = require('koa')
const app = new Koa()

app.use(async (ctx, next) => {
  console.log('开始行动')
  await next()
  const rt = ctx.response.get('X-Response-Time')
  console.log(`${ctx.method} ${ctx.url} - ${rt}`)
})
// 中间件
app.use(async (ctx, next) => {
  const start = Date.now()
  console.log('哈,我来了')
  await next()
  console.log('到家了')
  const ms = Date.now() - start
  ctx.set('X-Response-Time', `${ms}ms`)
})

// 中间件
app.use(async (ctx, next) => {
  console.log('我们一起吃饭吧')
  await next()
  console.log('在路上了')
})

// 中间件
app.use(async (ctx, next) => {
  console.log('吃完饭，准备走了')
  ctx.body = '小马哥'
})


// app.get()

app.listen(5000, () => {
  console.log('5000端口被监听了')
})

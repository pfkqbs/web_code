const Koa = require('koa')
const app = new Koa()
const { accessLogger, logger } = require('./logger')
// 错误处理中间件
app.use(accessLogger())
app.use(async (ctx, next) => {
  // ctx.throw(401, '未授权', { data: '你看看来' })
  ctx.body = '小马哥'
})
// 全局的事件监听器
app.on('error', (err) => {
  console.log('全局错误处理：', err.message, err.status, err.data)
  logger.error(err)
})

app.listen(5000, () => {
  console.log('5000端口被监听了')
})

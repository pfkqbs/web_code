const Koa = require('koa')
const app = new Koa()

// 错误处理中间件
app.use(async (ctx, next) => {
  try {
    await next()
  } catch (error) {
    const { status, data, message } = error
    // switch语句
    ctx.body = {
      code: status,
      message,
      data,
    }
    // 手动触发全局的错误函数
    // ctx.app.emit('error', error, ctx)
  }
})

app.use(async (ctx, next) => {
  ctx.throw(401, '未授权', { data: '你看看来' })
  // 等价的
  // const err = new Error('未授权')
  // err.status = 401,
  // err.expose = true
  // throw err
})

app.on('error', (err) => {
  console.log('全局错误处理：', err.message, err.status, err.data)
})

app.listen(5000, () => {
  console.log('5000端口被监听了')
})

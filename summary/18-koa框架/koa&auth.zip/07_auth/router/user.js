const Router = require('@koa/router')
const router = new Router()
const jwt = require('jsonwebtoken')
const jwtAuth = require('koa-jwt')
const axios = require('axios')
const secret = 'this is a secret'
router.prefix('/user')
router.get('/', async (ctx, next) => {
  ctx.body = '用户页面'
})
router.post('/login', async (ctx, next) => {
  const { user } = ctx.request.body
  ctx.session.userInfo = user
  ctx.body = {
    code: 200,
    message: '登录成功',
  }
})

router.get('/userInfo', require('../middleware/auth.js'), async (ctx, next) => {
  ctx.body = {
    code: 200,
    message: '数据获取成功',
    userInfo: ctx.session.userInfo,
  }
})

// jwt token
router.post('/login-token', async (ctx, next) => {
  const { body } = ctx.request
  const userInfo = body.user
  // 省略校验动作

  ctx.body = {
    code: 200,
    message: '登录成功',
    user: userInfo.user,
    token: jwt.sign(
      {
        data: userInfo, // 由于签名不是加密，令牌不要存放敏感数据 命名空间
        exp: Math.floor(Date.now() / 1000) + 60 * 60,
      },
      secret
    ),
  }
})
router.get('/getUser-token', jwtAuth({ secret }), async (ctx, next) => {
  ctx.body = {
    code: 200,
    message: '数据获取成功',
    userInfo: ctx.state.user.data,
  }
})
// oauth认证
// 用户的id和密钥
const config = {
  client_id: '90ba917a3b9f57284508',
  client_secret: '32ee5a08bdeab67500f986f742af0ae8e3cd5931',
}

router.get('/login-github', async (ctx, next) => {
  // 重定向到认证接口,并配置参数
  const path = `https://github.com/login/oauth/authorize?client_id=${config.client_id}`
  // 转发到授权服务器
  ctx.redirect(path)
})

router.get('/oauth/github/callback', async (ctx) => {
  //这是一个授权回调，用于获取授权码 code
  const code = ctx.query.code //// GitHub 回调传回 code 授权码
  // 带着 授权码code、client_id、client_secret 向 GitHub 认证服务器请求 token
  const params = {
    client_id: config.client_id,
    client_secret: config.client_secret,
    code: code,
  }

  let res = await axios.post(
    'https://github.com/login/oauth/access_token',
    params
  )
  const access_token = querystring.parse(res.data).access_token
  // 带着 token 从 GitHub 获取用户信息
  res = await axios.get(
    'https://api.github.com/user?access_token=' + access_token
  )
  console.log('userAccess', res.data)
  ctx.redirect('/hello.html')
})

module.exports = router

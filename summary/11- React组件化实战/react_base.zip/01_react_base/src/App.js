import React, { useRef } from 'react'
import logo from './logo.svg'
import './App.css'
import ChildComponent from './ChildComponent'

// react组件的两种声明方式：函数式组件 （hooks）和类组件
const arr = [1, 2, 3, 4]

const imgLogo = React.createRef()
class App extends React.Component {
  constructor(props) {
    super(props)
    // 修改状态的唯一方式是setState
    this.state = {
      count: 0,
      myName: '小马哥',
    }
  }
  add() {
    // refs已经被废弃掉
    // console.log(this.refs.imgLogo)
    console.log(imgLogo.current)
    // 它是个异步
    /*  this.setState(
      {
        count: this.state.count + 1,
      },
      () => {
        console.log(this.state.count) //最新的值
      }
    ) */
    this.setState(
      (prevState, prevProps) => {
        return {
          count: prevState.count + 1,
        }
      },
      () => {
        console.log(this.state.count)
      }
    )
  }
  render() {
    console.log('渲染了')
    return (
      <div>
        <h2>hello jsx</h2>
        <h2>{1 + 1}</h2>
        <h3>{this.state.count}</h3>
        <img src={logo} alt="logo" ref={imgLogo} />
        <ul>{arr.length > 0 && arr.map((item) => <li>{item}</li>)}</ul>
        <button onClick={() => this.add()}>+1</button>
        <h2>组件通信</h2>
        <ChildComponent
          name={this.state.myName}
          onHandleClick={(val) => {
            console.log(val)
            this.setState({
              myName: val,
            })
          }}
        ></ChildComponent>
      </div>
    )
  }
}
export default App

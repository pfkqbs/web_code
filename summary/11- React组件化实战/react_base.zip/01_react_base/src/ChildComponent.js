import React, { Component } from 'react'
import ProTypes from 'prop-types'
class ChildComponent extends Component {
  handleClick() {
    this.props.onHandleClick('大马哥')
  }
  render() {
    return (
      <>
        <h3>{this.props.name}</h3>
        <button onClick={() => this.handleClick()}>回调</button>
      </>
    )
  }
}
ChildComponent.propTypes = {
  name: ProTypes.string.isRequired,
}
export default ChildComponent

import React, { Component } from 'react'

class ControlInput extends Component {
  constructor(props) {
    super(props)
    this.state = {
      val: '',
    }
    this.inputRef = React.createRef()
  }
  handleChange = (e) => {
    // 受控组件
    /*  this.setState({
            val:e.target.value
        }) */
    // console.log(this.inputRef.current.value)
    /* 
        非受控组件
    */
    this.setState({
      val: this.inputRef.current.value,
    })
  }
  render() {
    return (
      <>
        <input
          type="text"
          value={this.state.val}
          onChange={this.handleChange}
          ref={this.inputRef}
        />
      </>
    )
  }
}

export default ControlInput

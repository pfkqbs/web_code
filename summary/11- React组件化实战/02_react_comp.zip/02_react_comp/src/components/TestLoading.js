import React, { Component } from 'react'
import { withLoadingHoc } from './HOC/withLoadingHoc'
class TestLoading extends Component {
  render() {
    return (
      <>
        <ul>
          {this.props.data.map((item) => {
            return <li key={item}>{item}</li>
          })}
        </ul>
      </>
    )
  }
}

export default withLoadingHoc(TestLoading)

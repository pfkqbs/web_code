import React, { Component } from 'react'
const withName = (WrapperComponent) => {
  console.log('withName打印了')
  const newProps = {
    name: 'react Hoc',
  }
  return (props) => (
    <WrapperComponent {...props} {...newProps}></WrapperComponent>
  )
}
const withLog = (WrapperComponent) => {
  console.log(WrapperComponent.name + '渲染了')
  const newProps = {
    a: 1,
  }
  return (props) => (
    <WrapperComponent {...props} {...newProps}></WrapperComponent>
  )
}
// 加工content 重写生命周期
const withContent = (WrapperComponent) => {
  return class extends Component {
    constructor(props) {
      super(props)
      this.state = {
        content: '',
      }
    }
    componentDidMount() {
      setTimeout(() => {
        this.setState({
          content: '高级组件的使用',
        })
      })
    }
    render() {
      return (
        <>
          <WrapperComponent
            {...this.props}
            content={this.state.content}
          ></WrapperComponent>
        </>
      )
    }
  }
}
// @withContent
// @withName
// @withLog
class Hoc extends Component {
  render() {
    return (
      <div>
        <h3>学习课程：{this.props.name}</h3>
        <h3>当前数值：{this.props.a}</h3>
        <p>学习内容：{this.props.content}</p>
      </div>
    )
  }
}

// export default withContent(withLog(withName(withLog(Hoc))))
export default Hoc

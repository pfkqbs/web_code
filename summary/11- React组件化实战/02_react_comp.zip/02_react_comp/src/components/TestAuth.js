import React from 'react'
import { withAdminAuth } from './HOC/withAdminAuth'
function TestAuth(props) {
  return <h3>页面A的内容</h3>
}

export default withAdminAuth({ role: 'user', isVip: true })(TestAuth)

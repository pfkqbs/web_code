import React, { Component, PureComponent } from 'react'

/* class Comment extends Component {
  shouldComponentUpdate(nextPorps){
    //   性能优化点
    if(nextPorps.data.id === this.props.data.id){
        return false
    }
    return true
  }
  render() {
    console.log('渲染了')
    const { title, author } = this.props.data
    return (
      <div>
        <h2>{title}</h2>---{author}
      </div>
    )
  }
} */
/* 
PureComponent 浅比较 比较的基本的数据类型
*/
/* class Comment extends PureComponent {
  render() {
    console.log('渲染了')
    const { title, author, id } = this.props
    return (
      <div>
        <h2>{title}</h2>---{author}--{id}
      </div>
    )
  }
} */

// React.memo()
const Comment = React.memo(({ id, title, author }) => {
  console.log('render')
  return (
    <div>
      <h2>{title}</h2>---{author}--{id}
    </div>
  )
})
class CommentList extends Component {
  constructor(props) {
    super(props)
    this.state = {
      comments: [],
    }
  }
  componentDidMount() {
    setInterval(() => {
      this.setState({
        comments: [
          {
            id: 1,
            title: 'react好',
            author: 'facebook',
          },
          {
            id: 2,
            title: 'vue3好',
            author: '小尤',
          },
        ],
      })
    }, 1000)
  }
  render() {
    return (
      <div>
        {/* <Comment key={item.id} data={item}></Comment>
             <Comment
            key={item.id}
            id={item.id}
            title={item.title}
            author={item.author}

          ></Comment>
         */}

        {this.state.comments.map((item) => (
          <Comment key={item.id} {...item}></Comment>
        ))}
      </div>
    )
  }
}

export default CommentList

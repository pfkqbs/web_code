import React, { Component } from 'react'
import withRender from './HOC/withRender'
class TestRender extends Component {
  render() {
    return <div>要渲染的内容</div>
  }
}

export default withRender(TestRender)

import React, { Component } from 'react'
function Dialog(props) {
  console.log(props)
  return (
    <div style={{ border: `4px solid ${props.borderColor}` }}>
      {props.children}
      {/* 具名插槽 */}
      {props.btn}
    </div>
  )
}
function WelcomDialog() {
  const confirmButton = <button>提交</button>
  return (
    <Dialog borderColor="green" btn={confirmButton}>
      <h3>欢迎光临</h3>
      <p>感谢使用React</p>
    </Dialog>
  )
}

class Compositon extends Component {
  render() {
    return (
      <div>
        <WelcomDialog></WelcomDialog>
      </div>
    )
  }
}

export default Compositon

import React from 'react'
export default function withRender(Comp) {
  return class extends Comp {
    render() {
      const elements = super.render()
      const newElements = React.cloneElement(elements, {
        children: '你的内容被我拦截了',
      })
      return newElements
    }
  }
}

import React from 'react'
// 让非受控组件变成受控组件
export default function withInputComponent(Comp) {
  return class Wrapper extends React.Component {
    state = {
      value: '',
    }
    onChange = (e) => {
      this.setState({ value: e.target.value })
    }
    render() {
      const newProps = { value: this.state.value, onChange: this.onChange }
      return <Comp {...this.props} {...newProps}></Comp>
    }
  }
}

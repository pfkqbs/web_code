import React from 'react'
// 控制组件的渲染时机（可以做全局的loading）
/* export const withLoadingHoc = (Comp) => {
  return class Wrapper extends React.Component {
    render() {
      if (!this.props.data.length) {
        return <span>Loading...</span>
      } else {
        return <Comp {...this.props}></Comp>
      }
    }
  }
} */
// 反向继承来实现高阶组件
export const withLoadingHoc = (Comp) => {
  return class Wrapper extends Comp {
    render() {
      if (!this.props.data.length) {
        return <span>Loading...</span>
      } else {
        return super.render()
      }
    }
  }
}

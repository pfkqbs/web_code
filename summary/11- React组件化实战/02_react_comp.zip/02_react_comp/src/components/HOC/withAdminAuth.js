import React, { Component } from 'react'

// 验证页面权限的高级组件
export const withAdminAuth =
  ({ role, isVip }) =>
  (WrapperComp) => {
    return class extends Component {
      constructor(props) {
        super(props)
        this.state = {
          isAuth: false,
        }
      }
      componentDidMount() {
        //   已经从后端获取到该页面的用户权限
        const currentRole = 'admin'
        const currentVip = true
        this.setState({
          isAuth: currentRole === role || currentVip === isVip,
        })
      }
      render() {
        if (this.state.isAuth) {
          return <WrapperComp {...this.props}></WrapperComp>
        }else{
            return <h3>您没有权限访问此页面，请联系管理gao1313djh</h3>
        }
      }
    }
  }

import React, { Component } from 'react'
function Cart(props) {
  return (
    <table border="1">
      <tbody>
        {props.cart.map((item) => {
          return (
            <tr key={item.id}>
              <td>名称：{item.title}</td>
              <td>单价：{item.price}</td>
              <td>
                <button>-</button>
                {item.count}
                <button>+</button>
              </td>
              <td>总价：{item.price * item.count}</td>
            </tr>
          )
        })}
      </tbody>
    </table>
  )
}

class CartSimple extends Component {
  constructor(props) {
    super(props)
    this.state = {
      title: '',
      price: '',

      goods: [],
      // 购物车数据
      cart: [],
    }
  }
  componentDidMount() {
    //   模拟ajax请求,与后端交互
    setTimeout(() => {
      let goods = [
        {
          id: new Date().toLocaleTimeString(),
          title: 'react组件化',
          price: 20,
        },
        {
          id: new Date().toLocaleTimeString() + '111',
          title: 'react hooks',
          price: 10,
        },
      ]
      this.setState({
        goods,
      })
    }, 1000)
  }
  handlePrice(e) {
    this.setState({
      price: e.target.value,
    })
  }
  handleTitle(e) {
    this.setState({
      title: e.target.value,
    })
  }
  addGood() {
    if (this.state.title && this.state.price) {
      this.setState(
        {
          goods: [
            ...this.state.goods,
            {
              id: new Date().toLocaleDateString(),
              title: this.state.title,
              price: this.state.price,
            },
          ],
        },
        () => {
          this.setState({
            title: '',
            price: '',
          })
          console.log(this.state.goods)
        }
      )
    }
  }
  //   加购
  addShopCart(i) {
    const newCart = [...this.state.cart]
    const good = this.state.goods[i]
    const idex = newCart.findIndex((item) => item.title === good.title)
    const cartGood = newCart[idex]
    if (cartGood) {
      // 证明已经有商品
      newCart.splice(idex, 1, { ...cartGood, count: cartGood.count + 1 })
    } else {
      // 第一次添加
      newCart.push({ ...good, count: 1 })
    }
    this.setState({
      cart: newCart,
    })
  }
  render() {
    return (
      <div>
        <h2>我的购物车</h2>
        <div className="cart">
          <p>
            <label htmlFor="title">课程:</label>
            <input
              type="text"
              id="title"
              value={this.state.title}
              onChange={(e) => this.handleTitle(e)}
            />
          </p>
          <p>
            <label htmlFor="price">价格:</label>
            <input
              type="text"
              id="price"
              value={this.state.price}
              onChange={(e) => this.handlePrice(e)}
            />
          </p>

          <button onClick={() => this.addGood()}>添加商品</button>
          <ul>
            {this.state.goods.length > 0 &&
              this.state.goods.map((item, i) => (
                <li key={item.id}>
                  <span>
                    {item.title}-¥ <span>{item.price}</span>
                    <button onClick={() => this.addShopCart(i)}>加购</button>
                  </span>
                </li>
              ))}
          </ul>
          <hr />
          <Cart cart={this.state.cart}></Cart>
        </div>
      </div>
    )
  }
}

export default CartSimple

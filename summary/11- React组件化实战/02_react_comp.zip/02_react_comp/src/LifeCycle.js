import React, { Component } from 'react'
import PropTypes from 'prop-types'
class SubChild extends Component {
  shouldComponentUpdate(nextProps, nextState) {
    if (nextProps.count > 1000) {
      return false
    }
    return true
  }
  render() {
    console.log('子组件渲染了')
    return <div>子组件的值:{this.props.count}</div>
  }
}

class LifeCycle extends Component {
  constructor(props) {
    super(props)
    console.log('1.初始化组件')
    this.state = {
      count: props.count,
      isUpdate: false,
    }
  }
  //   此方法是静态方法,不能访问this,替代componentWillReceiveProps
  static getDerivedStateFromProps(nextProps, prevState) {
    console.log('2.组件接受属性和状态', nextProps, prevState)
    const { isUpdate } = nextProps
    if (isUpdate !== prevState.isUpdate) {
      return {
        count: prevState.count,
      }
    }
    // 否则 对于state不进行任何操作
    return null
  }

  //   componentWillMount() {}

  componentDidMount() {
    console.log('3.组件已经挂载')
  }

  //   componentWillReceiveProps(nextProps) {}

  shouldComponentUpdate(nextProps, nextState) {
    return true
  }

  //   componentWillUpdate(nextProps, nextState) {}
  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log('更新之前被调用', prevState)
    return null
  }

  componentDidUpdate(prevProps, prevState) {
    console.log('组件更新完成')
  }

  componentWillUnmount() {
    //   清空定时器
    console.log('组件将要卸载')
  }
  updateCount() {
    this.setState((prevState) => {
      return {
        count: prevState.count + 100,
        isUpdate: true,
      }
    })
  }

  render() {
    console.log('LifeCycle组件渲染')
    return (
      <div>
        测试生命周期钩子 {this.state.count}
        <button onClick={() => this.updateCount()}>更新</button>
        <SubChild count={this.state.count}></SubChild>
      </div>
    )
  }
}

LifeCycle.propTypes = {}

export default LifeCycle

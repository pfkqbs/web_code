import React, { useState } from 'react'
import CartSimple from './CartSimple'
import ControlInput from './ControlInput'
import LifeCycle from './LifeCycle'
import CommentList from './components/CommentList'
import Compositon from './components/Compositon'
import Hoc from './components/Hoc'
import TestAuth from './components/TestAuth'
import TestLoading from './components/TestLoading'
import TestRender from './components/TestRender'
function App(props) {
  const [data, setData] = useState([])
  setTimeout(() => {
    setData([1, 2, 3, 4])
  }, 6000)
  return (
    <div>
      <CartSimple></CartSimple>
      <hr />
      <h3>受控组件和非受控组件</h3>
      <ControlInput></ControlInput>
      <h3>生命周期钩子</h3>
      {/* <LifeCycle isUpdate={true} count={100}></LifeCycle> */}
      <hr />
      <h3>性能优化手段</h3>
      <CommentList></CommentList>
      <hr />
      <h3>学习组件组合</h3>
      <Compositon></Compositon>
      <hr />
      <h3>高阶组件的学习</h3>
      <Hoc name="高阶组件"></Hoc>
      <hr />
      <h3>高阶组件案例</h3>
      <TestAuth></TestAuth>
      <TestLoading data={data}></TestLoading>
      <TestRender></TestRender>
    </div>
  )
}

export default App

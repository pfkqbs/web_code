import Taro from "@tarojs/taro";

export default () => {
  Taro.setNavigationBarTitle({ title: "微信小程序专属页面标题" });
  Taro.setNavigationBarColor({ backgroundColor: "#00b388", frontColor: '#ffffff' });
};

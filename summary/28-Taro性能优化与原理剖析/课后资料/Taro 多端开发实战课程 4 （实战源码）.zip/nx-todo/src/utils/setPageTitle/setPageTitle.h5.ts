export default () => {
  document.title = "H5 专属页面标题";
};

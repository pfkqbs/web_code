export default () => console.log("default");

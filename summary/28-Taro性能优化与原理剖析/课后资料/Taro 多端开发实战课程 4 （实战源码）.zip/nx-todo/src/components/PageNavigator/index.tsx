import React from "react";
import { Text, View } from "@tarojs/components";
import { AtIcon } from "taro-ui";
import "./index.scss";

export interface PageNavigatorProps {}

const PageNavigator: React.FC<PageNavigatorProps> = () => {
  return (
    <View className="page-navigator-wrapper">
      <View className="icon-wrapper">🌻</View>
      <View className="title-wrapper">
        <Text style={{ marginRight: 4 }}>今天</Text>
        <AtIcon value="chevron-down" size={12} />
      </View>
    </View>
  );
};

export default PageNavigator;

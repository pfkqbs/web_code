import React, { useCallback } from "react";
import { View } from "@tarojs/components";
import cls from "classnames";
import "./index.scss";

export interface NXCheckBoxProps {
  value: boolean;
  onChange?: (checked: boolean) => void;
}

const NXCheckBox: React.FC<NXCheckBoxProps> = ({ value, onChange }) => {
  const handleChange = useCallback(() => {
    onChange?.(!value);
  }, [onChange, value]);
  return (
    <View
      className={cls("nx-checkbox-wrapper", { checked: value })}
      onClick={handleChange}
    ></View>
  );
};

export default NXCheckBox;

import React, { useCallback } from "react";
import { View } from "@tarojs/components";
import { useFieldArray, useFormContext } from "react-hook-form";
import TodoAdder from "@components/TodoAdder";
import TodoItem, { TodoItemDataType } from "./TodoItem";

export interface TodoListProps {}

const TodoList: React.FC<TodoListProps> = () => {
  const { control } = useFormContext<{
    todoList: TodoItemDataType[];
  }>();
  const { fields, append } = useFieldArray({
    control: control,
    name: "todoList",
  });

  const handleAdd = useCallback(() => {
    append({ id: fields.length, isNew: true });
  }, [append, fields.length]);

  return (
    <View>
      {fields.map((item, index) => (
        // 面试官：循环遍历的组件为什么需要添加 key？
        <TodoItem key={item.id} index={index} data={item} />
      ))}
      <TodoAdder onAdd={handleAdd} />
    </View>
  );
};

export default TodoList;

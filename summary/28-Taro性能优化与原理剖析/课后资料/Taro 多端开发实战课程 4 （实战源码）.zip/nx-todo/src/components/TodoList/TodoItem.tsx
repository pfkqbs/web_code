import React from "react";
import { AtTextarea } from "taro-ui";
import { View, Text } from "@tarojs/components";
import cls from "classnames";
import { Controller, useFormContext, useWatch } from "react-hook-form";
import NXCheckBox from "@components/NXCheckBox";
import "./index.scss";

export type TodoItemDataType = {
  id: number;
  title: string;
  isNew?: boolean;
  isDone: boolean;
};

export interface TodoItemProps {
  index: number;
  data: TodoItemDataType;
  onChange?: (val: string) => void;
  onBlur?: () => void;
}

const TodoItem: React.FC<TodoItemProps> = ({ index }) => {
  const { control, setValue } = useFormContext<{
    todoList: TodoItemDataType[];
  }>();
  // 对象数据尽量在使用前解构，为什么呢？
  // 因为原型链查找属性或方法，如果频繁使用.访问操作符，会对性能有所影响
  const { title, isNew, isDone } = useWatch({
    control,
    name: `todoList.${index}`,
  });

  const content = isNew ? (
    <Controller
      control={control}
      name={`todoList.${index}.title`}
      render={({ field }) => (
        <AtTextarea
          value={field.value}
          onChange={(val) => field.onChange(val)}
          onBlur={() => setValue(`todoList.${index}.isNew`, false)}
        />
      )}
    />
  ) : (
    <Text className={cls({ "is-done": isDone })}>{title}</Text>
  );

  return (
    <View className="todo-item-wrapper">
      <View style={{ marginRight: "0.2rem" }}>
        <Controller
          control={control}
          name={`todoList.${index}.isDone`}
          render={({ field }) => <NXCheckBox {...field} />}
        />
      </View>

      <View className="todo-item-conten-warpper">
        <View style={{ margin: "0 4px" }}>❄️</View>
        {content}
      </View>
    </View>
  );
};

export default TodoItem;

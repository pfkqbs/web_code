import React from "react";
import { AtIcon } from "taro-ui";
import { View } from "@tarojs/components";
import "./index.scss";

export interface TodoAdderProps {
  onAdd?: () => void;
}

const TodoAdder: React.FC<TodoAdderProps> = ({ onAdd }) => {
  return (
    <View className="todo-adder-wrapper" onClick={onAdd}>
      <AtIcon value="add" size="24" />
    </View>
  );
};

export default TodoAdder;

import React, { useEffect } from "react";
import { View, Text } from "@tarojs/components";
import { AtButton, AtCheckbox } from "taro-ui";
import setPageTitle from "@utils/setPageTitle/setPageTitle";
import Modal from "@components/Modal";
import "./index.scss";

const Index: React.FC = () => {
  const platform = process.env.TARO_ENV;
  // 组件挂载时，组件卸载时
  useEffect(() => {
    setPageTitle();
  }, [platform]);
  return (
    <View>
      <Text>Hello {platform === "h5" ? "H5" : "微信小程序"}</Text>
      <Modal />
      <AtCheckbox
        selectedList={["man"]}
        options={[
          { label: "男", value: "man" },
          { label: "女", value: "woman" },
        ]}
        onChange={(val) => console.log(val)}
      />
      <AtButton>Helo Taro ui</AtButton>
    </View>
  );
};

export default Index;

import React from "react";
import { View } from "@tarojs/components";
import { FormProvider, useForm } from "react-hook-form";
import { TodoItemDataType } from "@components/TodoList/TodoItem";
import PageNavigator from "@components/PageNavigator";
import TodoList from "@components/TodoList";
import "./index.scss";

const Today: React.FC = () => {
  // provider
  // 输入组件，form 相关，form state 存储
  const methods = useForm<{ todoList: TodoItemDataType[] }>({
    defaultValues: {
      todoList: [
        { id: 1, title: "待办事项哈哈", isDone: false },
        { id: 2, title: "要买个锅", isDone: true },
      ],
    },
  });

  return (
    <View className="page-wrapper">
      <FormProvider {...methods}>
        <PageNavigator />
        <TodoList />
      </FormProvider>
    </View>
  );
};

export default Today;

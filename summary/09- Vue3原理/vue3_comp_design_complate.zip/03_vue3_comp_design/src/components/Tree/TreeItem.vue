<template>
  <div>
    <div :class="{ bold: isFolder }" @click="toggle">
      <CaretRightOutlined v-if='isFolder' :class="{ rodate: isOpen }"></CaretRightOutlined>
      {{ item.name }}
    </div>
    <div class="item" v-show="isOpen" v-if="isFolder">
      <tree-item
        class="item"
        v-for="(child, i) in item.children"
        :key="index"
        :item="child"
      >
      </tree-item>
    </div>
  </div>
</template>

<script setup>
import { CaretRightOutlined } from '@ant-design/icons-vue'
import { computed, ref } from 'vue'
const props = defineProps({
  item: {
    type: Object,
    default: () => {},
  },
})
const isOpen = ref(false)

const isFolder = computed(() => {
  return props.item.children && props.item.children.length > 0
})
const toggle = () => {
  if (isFolder) {
    isOpen.value = !isOpen.value
  }
}
</script>

<style scoped>
.bold {
  font-weight: bold;
  color: red;
}
div.item {
  padding-left: 10px;
}
.rodate {
  transform: rotate(90deg);
}
</style>

<template>
  <div class="carousel" @mouseenter="stop()" @mouseleave="start()">
    <ul class="carousel-body">
      <li
        class="carousel-item"
        v-for="(item, i) in list"
        :key="item.key"
        :class="{ fade: index === i }"
      >
        <!-- <RouterLink to="/"> -->
        <img :src="item.imgUrl" alt="" />
        <!-- </RouterLink> -->
      </li>
    </ul>
    <!-- 左右控制按钮 -->
    <a href="javascript:;" class="carousel-btn prev" @click="toggle(-1)"
      >&lt;</a
    >
    <a href="javascript:;" class="carousel-btn next" @click="toggle(1)">&gt;</a>
    <!-- 分页器 -->
    <div class="carousel-indicator">
      <span
        v-for="(item, i) in list"
        :key="item.id"
        :class="{ active: index === i }"
        @click="index = i"
      ></span>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'
const index = ref(0)
const props = defineProps({
  list: {
    type: Array,
    default: () => [],
  },
  duration: {
    type: Number,
    default: 3000,
  },
  autoplay: {
    type: Boolean,
    default: false,
  },
})
let timer = null
const autoPlayFn = () => {
  clearInterval(timer)
  timer = setInterval(() => {
    index.value++
    if (index.value >= props.list.length) {
      index.value = 0
    }
  }, props.duration)
}
const stop = () => {
  if (timer) clearInterval(timer)
}
const start = () => {
  if (props.list.length && props.autoplay) {
    autoPlayFn()
  }
}
watch(
  () => props.list,
  (n) => {
    console.log(n)
    if (n.length > 1 && props.autoplay) {
      index.value = 0
      autoPlayFn()
    }
  },
  { immediate: true }
)
// 轮播图左右按钮切换事件
const toggle = (step) => {
  index.value += step
  // 确定右侧临界值
  if (index.value >= props.list.length) {
    index.value = 0
    return
  }

  // 确定左侧的临界值
  if (index.value < 0) {
    index.value = props.list.length - 1
  }
}
</script>

<style lang="less" scoped>
@import './index.less';
</style>

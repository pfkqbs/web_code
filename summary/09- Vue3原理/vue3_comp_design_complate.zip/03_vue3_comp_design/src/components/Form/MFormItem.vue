<template>
  <div class="m-form-item">
    <label for="" style="margin-right: 10px">{{ label }}</label>
    <slot></slot>
    <p class="errors">
      {{ error }}
    </p>
  </div>
</template>

<script setup>
import { onMounted, inject, provide, ref, reactive, toRefs } from 'vue'
import Schema from 'async-validator'
import mitt from 'mitt'
const emitter = mitt()
const props = defineProps(['label', 'prop'])
const mForm = inject('mForm')
const error = ref('')
// 真正的校验方法
const validate = () => {
  // console.log(props)
  // form-item: prop=>name
  // form-item: prop=>pwd
  // form-item组件上没有prop属性，不去校验
  if (!props.prop) return
  const rules = mForm.rules[props.prop]
  const value = mForm.model[props.prop]
  //   console.log(rules)
  const validator = new Schema({ [props.prop]: rules })
  return validator.validate({ [props.prop]: value }, (errors) => {
    console.log(errors)
    //  errors存在则校验失败
    if (errors) {
      error.value = errors[0].message
    } else {
      //校验通过
      error.value = ''
    }
  })
}
const mFormItem = reactive({
  ...toRefs(props),
  formItemEmitter: emitter,
  validate,
})
provide('mFormItem', mFormItem)
onMounted(() => {
  // 组件加载时，监听表单控件输入或者blur校验
  emitter.on('validate', validate)

  if (props.prop) {
    mForm.fomEmitter.emit('m.form.addField', mFormItem)
  }
})
</script>

<style lang="less" scoped>
p.errors {
  color: red;
  font-size: 14px;
}
</style>

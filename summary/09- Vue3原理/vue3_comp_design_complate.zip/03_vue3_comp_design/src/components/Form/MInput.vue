<template>
  <input
    type="text"
    :value="modelValue"
    @input="handleChange"
    @blur="handleBlur"
  />
</template>

<script setup>
import { inject } from 'vue'
const mFormItem = inject('mFormItem')
defineProps({
  modelValue: {
    type: String,
  },
})
const emit = defineEmits(['update:modelValue'])
const handleChange = (e) => {
  emit('update:modelValue', e.target.value)
  //   通知formitem校验
  mFormItem && mFormItem.formItemEmitter.emit('validate')
}
const handleBlur = () => {
  //   通知formitem校验
  mFormItem && mFormItem.formItemEmitter.emit('validate')
}
</script>

<style lang="less" scoped></style>

form组件
- 接收model,保存表单数据
- 接收校验规则rules
- 提供表单验证校验方法validate,调用子组件（form-item）的校验方法
- 将model和rules数据传递给form-item

formItem组件
- 接收label,用于显示表单项的文本
- 接收prop,当前表单项的key,用于获取校验规则，表单项的值
- 提供validate方法，校验当前表单项
- 组件加载的时候，派发事件 给form组件添加formItem
input组件实现
- 实现v-model
- blur和input事件触发校验

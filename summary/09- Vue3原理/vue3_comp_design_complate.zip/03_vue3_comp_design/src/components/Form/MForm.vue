<template>
  <div class="m-form">
    <slot></slot>
  </div>
</template>

<script setup>
import { reactive, provide, toRefs } from 'vue'
import mitt from 'mitt'
const emitter = mitt()
const props = defineProps({
  model: {
    type: Object,
    default: () => {},
  },
  rules: {
    type: Object,
    default: () => {},
  },
})
const fileds = reactive([])
// 提供表单整体校验方法validate, 调用m-form-item的校验方法
const validate = (cb) => {
  // TODO : 调用子组件m-form-item的校验方法
  const tasks = fileds.map((item) => item.validate())
  Promise.all(tasks)
    .then(() => cb(true))
    .catch(() => {
      console.log('校验失败')
      cb(false)
    })
}
// 监听表单项是否注册，如果一旦注册，就存放到栈中
emitter.on('m.form.addField', (field) => {
  field && fileds.push(field)
})
const mForm = reactive({
  fomEmitter: emitter,
  ...toRefs(props),
})
provide('mForm', mForm)
defineExpose({
  validate,
})
</script>

<style lang="less" scoped></style>

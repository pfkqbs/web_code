<template>
  <a :href="to" v-if="isExternal" v-bind="$attrs" target="_blank">
    <slot></slot>
  </a>
  <router-link v-bind="$props" v-else>
    <slot></slot>
  </router-link>
</template>

<script setup>
import { computed } from 'vue'
// isExternal: true  a ;false router-link
import { RouterLink } from 'vue-router'
console.log(RouterLink.props)
const props = defineProps({
  ...RouterLink.props,
})
const isExternal = computed(() => {
  return typeof props.to === 'string' && props.to.startsWith('http')
})
</script>

<style lang="less" scoped></style>

/**
 * Mocking client-server processing
 */
const _products = [
  { id: 1, title: '红烧茄子', price: 10, inventory: 2 },
  { id: 2, title: '烤韭菜', price: 12, inventory: 10 },
  { id: 3, title: '烤羊肉串', price: 20, inventory: 5 },
]

export default {
  // 获取所有商品的方法
  getProducts() {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // cb(_products)
        resolve({ code: 1, message: null, data: _products })
      }, 100)
    })
  },
  //   购买的方法 支付成功或者失败
  buyProducts(products, cb, errorCb) {
    setTimeout(() => {
      // simulate random checkout failure.
      Math.random() > 0.5 ? cb() : errorCb()
    }, 100)
  },
}

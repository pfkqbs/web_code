import { createStore, createLogger } from 'vuex'
import products from './modules/products'
import cart from './modules/cart'
import todo from './modules/todo'
import plugins from './plugins'
const store = createStore({
  state() {
    return {
      // 数据状态  全局下
      count: 0,
    }
  },
  //   计算属性
  getters: {
    evenOrOdd(state) {
      return state.count % 2 === 0 ? '偶数' : '奇数'
    },
  },
  //   修改状态的唯一方法是提交(commit)mutations中方法 它是同步的
  mutations: {
    increment(state, { value = 1 } = {}) {
      state.count += value
    },
    decrement(state) {
      state.count--
    },
    incrementIfOdd(state) {
      // 如果当前是偶数加1
      if ((state.count + 1) % 2 === 0) {
        state.count++
      }
    },
  },
  //   异步行为都会在这里做
  actions: {
    //   异步操作
    incrementAsync({ commit, dispatch }, { value }) {
      return new Promise((resolve, reject) => {
        setTimeout(() => {
          commit('increment')
          resolve(true)
        }, 1000)
      })
    },
  },
  plugins,
  //   必须要有命名空间 唯一标识 namespace: true
  modules: {
    products,
    cart,
    todo,
  },
})
export default store

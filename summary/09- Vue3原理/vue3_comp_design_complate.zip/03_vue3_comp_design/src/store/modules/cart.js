import shop from '@/api/shop'
import { message } from 'ant-design-vue'
const state = {
  // 将来存放购物车的数据
  // {id,title,price,quantity}
  items: [],
}
const getters = {
  // 获取购物车商品数据
  cartProducts: (state, getters, rootState) => {
    return state.items.map(({ id, quantity }) => {
      const product = rootState.products.all.find((p) => p.id === id)
      return {
        id: product.id,
        title: product.title,
        price: product.price,
        quantity,
      }
    })
  },
}
const mutations = {
  pushProductToCart(state, { id }) {
    state.items.push({
      id,
      quantity: 1,
    })
  },
  incrementItemQuantity(state, { id }) {
    const cartItem = state.items.find((item) => item.id === id)
    cartItem.quantity++
  },
}
const actions = {
  addProductToCart({ state, commit }, product) {
    // 商品有库存
    if (product.inventory > 0) {
      // 购物车数据+1
      const cartItem = state.items.find((item) => item.id === product.id)
      if (!cartItem) {
        commit('pushProductToCart', { id: product.id })
      } else {
        commit('incrementItemQuantity', cartItem)
      }
      //   商品库存要－1
      commit(
        'products/decrementProductInventory',
        { id: product.id },
        { root: true }
      )
    }
  },
}
export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions,
}

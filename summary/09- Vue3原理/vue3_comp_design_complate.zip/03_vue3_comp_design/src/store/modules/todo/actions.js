export default {
    addTodo ({ commit }, text) {
      commit('addTodo', {
        text,
        done: false,// 添加一个任务，默认未完成
      })
    },
  
    removeTodo ({ commit }, todo) {
      commit('removeTodo', todo)
    },
    // 单个任务的全选、反选
    toggleTodo ({ commit }, todo) {
      commit('editTodo', { todo, done: !todo.done })
    },
  
    editTodo ({ commit }, { todo, value }) {
      commit('editTodo', { todo, text: value })
    },
    
    // 全选/反选
    toggleAll ({ state, commit }, done) {
      console.log(done)
      state.todos.forEach((todo) => {
        commit('editTodo', { todo, done })
      })
    },
  
    clearCompleted ({ state, commit }) {
      state.todos.filter(todo => todo.done)
        .forEach(todo => {
          commit('removeTodo', todo)
        })
    }
  }
  
import shop from '@/api/shop'
import { message } from 'ant-design-vue'
const state = {
  // 所有的商品列表
  all: [],
}
const getters = {}
const mutations = {
  SET_PRODUCTS(state, products) {
    state.all = products
  },
  // 加购时，库存-1
  decrementProductInventory(state, { id }) {
    const product = state.all.find((item) => item.id === id)
    product.inventory--
  },
}
const actions = {
  // 获取所有的商品数据
  async getAllProducts({ commit }) {
    try {
      const { code, message, data } = await shop.getProducts()
      console.log(data)
      if (code !== 1) throw new Error(message)
      commit('SET_PRODUCTS', data)
    } catch (e) {
      message.error(e.message)
    }
  },
}
export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions,
}

import { createRouter, createWebHistory } from 'vue-router'
const routes = [
  {
    path: '/',
    redirect: '/home',
    component: () => import('../views/index.vue'),
    children: [
      {
        path: '/home',
        name: 'Home',
        meta: { title: '首页' },
        component: () => import('../views/Home'),
      },
      {
        path: '/shop',
        name: 'Shop',
        meta: { title: '商品' },
        component: () => import('../views/Shop'),
      },
      {
        path: '/todoList',
        name: 'TodoList',
        meta: { title: '任务待办事项' },
        component: () => import('../views/Todo'),
      },
      {
        path: '/pins',
        name: 'Pins',
        meta: { title: '沸点', hidden: true, icon: 'href' },
        component: () => import('../views/Pins'),
      },
      {
        path: '/course',
        name: 'Course',
        redirect: '/course/all',
        meta: {
          title: '课程',
          hiddenInChildren: true,
          icon: 'home',
          requireAuth: true,
        },
        component: () => import('../views/Course'),
        children: [
          {
            path: '/course/:courseName',
            // 动态路由匹配的组件，会被缓存，watch监听路由params的变化来进行数据获取
            component: () => import('../views/Course/Content'),
            props: true,
          },
        ],
      },
    ],
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login'),
  },

  // vue-router4.x 匹配404路由的方式
  {
    path: '/:pathMatch(.*)',
    component: () => import('../views/404'),
  },
]
const router = createRouter({
  history: createWebHistory(),
  routes,
})
// 全局路由钩子
router.beforeEach((to, from, next) => {
  const token = JSON.parse(localStorage.getItem('access_token'))
  if (to.meta.requireAuth && !token) {
    //用户未登录，需要认证
    // /course/all
    next({
      path: '/login',
      query: {
        redirect: to.fullPath,
      },
    })
  } else {
    next()
  }
})
export default router

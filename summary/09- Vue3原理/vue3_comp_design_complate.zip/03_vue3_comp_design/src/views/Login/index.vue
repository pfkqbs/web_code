<template>
  <div>
    <a-button type="primary" @click="handleLogin">登录</a-button>
  </div>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router'
const router = useRouter()
const route = useRoute()
const handleLogin = () => {
  setTimeout(() => {
    const user = {
      name: '小马哥',
      pwd: '123',
    }
    localStorage.setItem('access_token', JSON.stringify(user))
    router.push({
      path: route.query.redirect || '/',
    })
  }, 2000)
}
</script>

<style lang="less" scoped></style>

<template>
  <div>
      <router-link to='/course/all'>全部</router-link> |
      <router-link to='/course/backend'>后端</router-link> |
      <router-link to='/course/frontend'>前端</router-link>
      <router-view></router-view>
  </div>
</template>

<script setup></script>

<style lang="less" scoped></style>

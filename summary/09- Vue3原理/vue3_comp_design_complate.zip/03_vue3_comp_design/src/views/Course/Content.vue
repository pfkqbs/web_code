<template>
  <div>我是课程列表内容 -- {{ name }}</div>
  <button @click="router.push({ name: 'Home', query: { id: 1 } })">
    跳转到首页
  </button>
</template>

<script setup>
import { watch, ref } from 'vue'
import { useRouter, useRoute } from 'vue-router'
const router = useRouter()
const route = useRoute()
const name = ref('')
console.log(route)
// all frontend backend
watch(
  () => route.params,
  (n) => {
    console.log(n.courseName)
    name.value = n.courseName
    // 发起请求 根据不同参数，获取不同的数据
  },
  { immediate: true }
)
const props = defineProps(['courseName'])
console.log(props)
</script>

<style lang="less" scoped></style>

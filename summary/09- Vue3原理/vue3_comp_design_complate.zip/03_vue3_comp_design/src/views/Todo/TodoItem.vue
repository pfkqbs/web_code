<template>
  <li class="todo" :class="{ completed: todo.done, editing }">
    <div class="view">
      <input
        class="toggle"
        type="checkbox"
        :checked="todo.done"
        @change="toggleTodo(todo)"
      />
      <label v-text="todo.text" @dblclick="editing = true"></label>
      <button class="destroy" @click="removeTodo(todo)"></button>
    </div>
    <input
      class="edit"
      v-show="editing"
      :value="todo.text"
      ref="input"
      @keyup.enter="doneEdit"
      @keyup.esc="cancelEdit"
      @blur="doneEdit"
    />
  </li>
</template>

<script setup>
import { ref, watch, nextTick, defineProps } from 'vue'
import { useStore } from 'vuex'
const props = defineProps(['todo'])
const input = ref(null)

const editing = ref(false)

watch(editing, (v) => {
  v &&
    nextTick(() => {
      input.value.focus()
    })
})

const store = useStore()

const editTodo = (todo, value) =>
  store.dispatch('todo/editTodo', { todo, value })
const toggleTodo = (todo) => store.dispatch('todo/toggleTodo', todo)
const removeTodo = (todo) => store.dispatch('todo/removeTodo', todo)

function doneEdit(e) {
  const value = e.target.value.trim()
  console.log(value)
  if (!value) {
    //   如果没有值，直接移除当前任务
    removeTodo(props.todo)
  } else if (editing.value) {
    editTodo(props.todo, value)
  }
  editing.value = false
}

function cancelEdit(e) {
  e.target.value = props.todo.text
  editing.value = false
}
</script>

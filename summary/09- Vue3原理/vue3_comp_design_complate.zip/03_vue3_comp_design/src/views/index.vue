<template>
  <div>
    <div class="header">
      <ul>
        <li v-for="item in navList" :key="item?.title">
          <app-link :to="{ name: item.name }">
            {{ item?.meta?.title }}
          </app-link>
          <!-- <app-link to="/">首页</app-link> |
          <app-link to="/pins">沸点</app-link> |
          <app-link to="/course">课程</app-link> |
          <app-link to="http://www.jd.com">京东</app-link> -->
          <!-- <router-link to="/">首页</router-link> |
          <router-link to="/pins">沸点</router-link> |
          <router-link to="/course">课程</router-link> |
          <a href="http://www.jd.com">京东</a> -->
        </li>
        <li>
         <app-link to="http://www.jd.com">京东</app-link>
        </li>
      </ul>
      <a-button @click="router.push('/login')">登录</a-button>
      <a-button @click="handleLogout">退出</a-button>
    </div>
    <div class="content">
      <!-- 路由组件的出口 -->
      <router-view></router-view>
    </div>
  </div>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router'
import AppLink from '@/components/AppLink'

const router = useRouter()
const route = useRoute()
console.log(route)
const navList = route?.matched[0]?.children.filter((item) => !item?.hidden)
const handleLogout = () => {
  localStorage.removeItem('access_token')
}
</script>

<style lang="less" scoped></style>

<template>
  <div>我是沸点 {{ count }} -- {{ evenOrOdd }}</div>
  <a-button @click="handleIncrement">+1</a-button>
  <a-button @click="handleDecrement">-1</a-button>
  <a-button @click="handleIncrementAsync">异步+1</a-button>
</template>

<script setup>
import { isRef, computed } from 'vue'
import { useStore } from 'vuex'
const store = useStore()
const count = computed(() => store.state.count)
const evenOrOdd = computed(() => store.getters.evenOrOdd)
const handleIncrement = () => {
  store.commit('increment', { value: 1 })
}
const handleIncrementAsync = () => {
  store.dispatch('incrementAsync', { value: 1 })
}
const handleDecrement = () => {
  store.commit('decrement')
}
</script>

<style lang="less" scoped></style>

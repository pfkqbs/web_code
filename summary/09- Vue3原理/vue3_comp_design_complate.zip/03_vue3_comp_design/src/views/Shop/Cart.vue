<template>
  <div class="cart">
    <p v-show="!cartProducts.length">
      <i>购物车空空如也</i>
    </p>
    <ul>
      <li v-for="item in cartProducts" :key="item.id">
        {{ item.title }}-¥{{ item.price }} x {{ item.quantity }}
      </li>
    </ul>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useStore } from 'vuex'
const store = useStore()
const cartProducts = computed(() => store.getters['cart/cartProducts'])
</script>

<style lang="less" scoped></style>

<template>
  <ul>
    <li v-for="item in products" :key="item.id">
      {{ item.title }} - ¥{{ item.price }} - 库存：{{ item.inventory }}
      <br />
      <a-button danger @click="addToCart(item)" :disabled="!item.inventory"
        >加购</a-button
      >
    </li>
  </ul>
  <hr />
  <Cart></Cart>
</template>

<script setup>
import { computed } from 'vue'
import { useStore } from 'vuex'
import Cart from './Cart'
const store = useStore()
console.log(store.state)

const products = computed(() => store.state.products.all)
const addToCart = (p) => {
  store.dispatch('cart/addProductToCart', p)
}

store.dispatch('products/getAllProducts')
</script>

<style lang="less" scoped></style>

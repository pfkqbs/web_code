<template>
  <div>
    <!-- <h2>轮播图组件</h2>
    <div class="home-banner">
      <Carousel :list="list" :duration="1500" :autoplay="true"></Carousel>
    </div>
    <hr />
    <h2>树组件</h2>
    <TreeItem :item="treeData"> </TreeItem>
    <hr />
    <h2>表单组件</h2>
    <m-form ref="formRef" :model="formData" :rules="rules">
      <m-form-item label="名称" prop="name">
        <m-input v-model="formData.name"></m-input>
      </m-form-item>
      <m-form-item label="密码" prop="pwd">
        <m-input v-model="formData.pwd"></m-input>
      </m-form-item>
      <m-form-item>
        <button @click="handleSubmit">提交</button>
      </m-form-item>
    </m-form> -->
    <router-view></router-view>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import Carousel from './components/Carousel'
import TreeItem from './components/Tree/TreeItem'
import MForm from './components/Form/MForm.vue'
import MFormItem from './components/Form/MFormItem.vue'
import MInput from './components/Form/MInput.vue'
const formData = reactive({ name: '', pwd: '' })
const rules = {
  name: [
    {
      required: true,
      message: '请输入名称',
    },
  ],
  pwd: [
    {
      required: true,
      message: '请输入密码',
    },
  ],
}
const formRef = ref()
const handleSubmit = () => {
  formRef.value.validate((valid) => {
    console.log('valid', valid)
  })
}

const list = [
  {
    id: 1,
    imgUrl:
      'https://code-1307161657.cos.ap-beijing.myqcloud.com/images%2Fcloud.jpeg',
  },
  {
    id: 2,
    imgUrl:
      'https://code-1307161657.cos.ap-beijing.myqcloud.com/images%2Fground.jpeg',
  },
  {
    id: 3,
    imgUrl:
      'https://code-1307161657.cos.ap-beijing.myqcloud.com/images%2Fnight.jpeg',
  },
  {
    id: 4,
    imgUrl:
      'https://code-1307161657.cos.ap-beijing.myqcloud.com/images%2Fstreet.jpeg',
  },
  {
    id: 5,
    imgUrl:
      'https://code-1307161657.cos.ap-beijing.myqcloud.com/images%2Fsun.jpeg',
  },
]
const treeData = {
  name: 'My Tree',
  children: [
    { name: 'hello' },
    { name: 'wat' },
    {
      name: 'child folder',
      children: [
        {
          name: 'child folder',
          children: [{ name: 'hello' }, { name: 'wat' }],
        },
        { name: 'hello' },
        { name: 'wat' },
        {
          name: 'child folder',
          children: [{ name: 'hello' }, { name: 'wat' }],
        },
      ],
    },
  ],
}
</script>

<style lang="less" scoped>
.home-banner {
  width: 960px;
  height: 540px;
  margin: 0 auto;
}
</style>

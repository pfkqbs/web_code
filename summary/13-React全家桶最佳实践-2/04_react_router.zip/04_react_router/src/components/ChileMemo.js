import React, { memo } from 'react'

/* const ChileMemo = memo(({ name}) => {
  console.log('渲染了', name)
  return <div>我是孩子组件:{name}</div>
}) */
const ChileMemo = memo(({ userInfo }) => {
  console.log('渲染了', userInfo.name)
  return <div>我是孩子组件:{userInfo.name}</div>
})
export default ChileMemo

import React, { memo } from 'react'

const ChildCallBack = memo(({ name, handleClick }) => {
  console.log('渲染了：', name, handleClick)
  return <div>callback渲染了</div>
})

export default ChildCallBack

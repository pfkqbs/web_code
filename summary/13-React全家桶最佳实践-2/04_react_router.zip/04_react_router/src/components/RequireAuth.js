import React from 'react'
import { Navigate } from 'react-router-dom'
import { connect } from 'react-redux'
import { mapStateToProps } from '../store/user.reducer'
const RequireAuth = ({ children, user }) => {
  // console.log(user)
  let isLogin = user.isLogin
  return !isLogin ? <Navigate to="/login"></Navigate> : children
}

export default connect(mapStateToProps)(RequireAuth)

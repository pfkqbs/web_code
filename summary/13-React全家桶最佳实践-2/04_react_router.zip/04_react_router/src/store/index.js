import {
  legacy_createStore as createStore,
  combineReducers,
  applyMiddleware,
} from 'redux'
import logger from 'redux-logger'
import user from './user.reducer'
import createSagaMiddleware from 'redux-saga'
import saga from './redux.saga'
const mid = createSagaMiddleware()
const store = createStore(
  combineReducers({ user }),
  applyMiddleware(logger, mid)
)
mid.run(saga)
export default store

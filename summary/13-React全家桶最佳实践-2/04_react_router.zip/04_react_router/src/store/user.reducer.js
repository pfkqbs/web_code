const initState = {
  isLogin: false, // 表示用户未登录
}
function user(state = initState, action) {
  switch (action.type) {
    case 'login':
      return { ...initState, ...{ isLogin: true } }

    default:
      return initState
  }
}
export const mapStateToProps = (state) => {
  return {
    user: state.user,
  }
}
const login = () => {
  return { type: 'login_request' }
}
export const mapDispatchToProps = (dispatch) => {
  return {
    login() {
      dispatch(login())
    },
  }
}

export default user

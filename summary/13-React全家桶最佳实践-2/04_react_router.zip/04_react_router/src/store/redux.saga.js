import { call, put, takeEvery } from 'redux-saga/effects'
// 模拟请求api
const request = {
  handleLogin() {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (Math.random() > 0.5) {
          resolve({
            code: 200,
            data: {
              id: 1,
              name: '小马哥',
            },
            message: null,
          })
        } else {
          reject({ code: 401, message: '未授权', data: null })
        }
      }, 1000)
    })
  },
}

// work saga
function* login() {
  try {
    const result = yield call(request.handleLogin)
    console.log(result)
    yield put({ type: 'login', result })
  } catch (error) {
    yield put({ type: 'loginError', message: error.message })
  }
}

function* mySaga() {
  yield takeEvery('login_request', login)
}
export default mySaga

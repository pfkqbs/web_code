
// const store = createStore(
//     combineReducers({ user }),
//     applyMiddleware(logger, thunk)
//   )
export default function createStore(reducer, preloadedState, enhancer) {
  /*******************校验参数***********************/
  if (
    (typeof preloadedState === 'function' && typeof enhancer === 'function') ||
    (typeof enhancer === 'function' && typeof arguments[3] === 'function')
  ) {
    throw new Error(
      'It looks like you are passing several store enhancers to ' +
        'createStore(). This is not supported. Instead, compose them ' +
        'together to a single function.'
    )
  }
  // 当第二个参数没有传preloadedState,而直接传function的话,就会直接把这个function当成enchancer
  if (typeof preloadedState === 'function' && typeof enhancer === 'undefined') {
    enhancer = preloadedState
    preloadedState = undefined
  }
  // 当第三个数传递了,但类型不是函数,则报错
  if (typeof enhancer !== 'undefined') {
    if (typeof enhancer !== 'function') {
      throw new Error('Expected the enhancer to be a function.')
    }
    // createStore 作为enhancer的参数，返回一个被加强的createStore，然后再将reducer, preloadedState传进去生成store
    return enhancer(createStore)(reducer, preloadedState)
  }
  //第一个参数reducer 是必须要传递的而且必须是一个函数，不然Redux会报错
  if (typeof reducer !== 'function') {
    throw new Error('Expected the reducer to be a function.')
  }

  //store.getState()
  //仓库内部保存了一颗状态树。可以是任意类型
  let currentState = preloadedState
  let currentListeners = [] // 所有的监听函数
  /* 
    (state,action)=>{}
  
  */
  let currentReducer = reducer
  /**************************getState**********************/
  function getState() {
    return JSON.parse(JSON.stringify(currentState))
  }
//  const lister =  store.subscribe(()=>{})  移除this.lister()

  //添加监听函数listener,它会在每次dispatch action的时候调用
  function subscribe(listener) {
    //将监听函数放入一个队列中
    currentListeners.push(listener)
    // 返回一个移除listener的函数
    return function () {
      currentListeners = currentListeners.filter((item) => item !== listener)
    }
  }
  //重点函数,它的作用就是触发状态的改变
  // action 对象
//   counte:0
//   increment counte:1
  function dispatch(action) {
    //调用reducer进行处理，获取老的state,计算出新的state
    currentState = currentReducer(currentState, action)
    //通知执行
    currentListeners.forEach((l) => l())
    return action
  }
  //初始化的操作
  dispatch({ type: '@@INITxxxx' })
  return {
    getState,
    dispatch,
    subscribe,
  }
}

import { Navigate } from 'react-router-dom'
import Course from '../pages/Course'
import CourseList from '../pages/CourseList'
import CourseDetail from '../pages/CourseDetail'
import Home from '../pages/Home'
import Login from '../pages/Login'
import User from '../pages/User'
import NotFound from '../pages/NotFound'
import RequireAuth from '../components/RequireAuth'
const routes = [
  {
    path: '/',
    element: <Navigate to="/home"></Navigate>,
  },
  {
    path: '/home',
    element: <Home></Home>,
  },
  {
    path: '/course',
    element: <Course></Course>,
    children: [
      {
        index: true,
        element: <CourseList></CourseList>,
      },
      {
        path: ':name',
        element: <CourseDetail></CourseDetail>,
      },
    ],
  },
  {
    path: '/user/:id',
    element: (
      <RequireAuth>
        <User></User>
      </RequireAuth>
    ),
  },
  {
    path: '/login',
    element: <Login></Login>,
  },
  {
    path: '*',
    element: <NotFound></NotFound>,
  },
]
export default routes

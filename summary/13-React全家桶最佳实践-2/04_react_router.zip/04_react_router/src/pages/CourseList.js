import React from 'react';

const CourseList = () => {
    return (
        <div>
            我是课程列表
        </div>
    );
};

export default CourseList;
import React from 'react'
import { useParams,useLocation } from 'react-router-dom'
const User = () => {
  const params = useParams()
  console.log(useLocation())
  console.log(params.id)

  return <div>我是用户</div>
}

export default User

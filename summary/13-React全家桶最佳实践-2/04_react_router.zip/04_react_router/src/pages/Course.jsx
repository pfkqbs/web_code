import React from 'react';
import {Outlet,Link} from 'react-router-dom'
const Course = () => {
    return (
        <div>
            我是课程组件
            <Link to='/course'>课程列表</Link> |
            <Link to='/course/detail'>课程详情</Link> |
            <Outlet></Outlet>
        </div>
    );
};

export default Course;
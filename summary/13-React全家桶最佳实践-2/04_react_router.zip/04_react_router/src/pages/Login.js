import React from 'react'
import { connect } from 'react-redux'
import { mapStateToProps,mapDispatchToProps } from '../store/user.reducer'
const Login = (props) => {
  console.log(props)
  const handleLogin = () => {
    props.login()
  }
  return (
    <div>
      我是登录组件
      <button onClick={() => handleLogin()}>登录</button>
    </div>
  )
}

export default connect(mapStateToProps,mapDispatchToProps)(Login)

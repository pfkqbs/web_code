import React, { useEffect } from 'react'
import { useParams, useSearchParams } from 'react-router-dom'
const CourseDetail = () => {
  //   query查询
  const [searchParams, setSeachParams] = useSearchParams()

  useEffect(() => {
    console.log(searchParams.get('id'))
  }, [searchParams])

  const handleUpdateParams = () => {
    setSeachParams({
      id: 2222,
    })
  }
  return (
    <div>
      我是课程详情
      <button onClick={() => handleUpdateParams()}>修改</button>
    </div>
  )
}

export default CourseDetail

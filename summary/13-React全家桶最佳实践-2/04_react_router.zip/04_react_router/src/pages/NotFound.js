import React from 'react'

const NotFound = () => {
  return <div>我是404</div>
}

export default NotFound

import React, { useState, useCallback, useMemo, useEffect } from 'react'
import ChildMemo from '../components/ChileMemo'
import ChildCallBack from '../components/ChildCallBack'
/**
 * useCallback 记忆函数
 * useMemo 记忆复杂的数据结构
 *
 * 避免子组件重复性渲染
 * 
//  useEffect 相当于监听的作用  （模拟组件的生命周期）
useEffect(()=>{

    return {
        // 
    }
},[count])
 * @returns
 */
const Home = () => {
  // count相当于一个状态，约定set前缀+状态
  const [count, setCount] = useState(0)
  const [name, setName] = useState('小黄')
  //   useMemo() 返回一个memoized值
  const userInfo = useMemo(() => ({ name: '小黄', age: 18 }), [])
  const add = () => {
    setCount(count + 1)
  }
  /*  const onClick = ()=>{
      console.log('11111')
  } */
  const onClick = useCallback(() => {
    console.log(1111)
  }, [])
  return (
    <div>
      我是首页 {count}
      <button onClick={add}>点击次数: {count}</button>
      {/* <ChildMemo name={name}></ChildMemo> */}
      {/* <ChildMemo userInfo={userInfo}></ChildMemo> */}
      <ChildCallBack name={name} handleClick={onClick}></ChildCallBack>
    </div>
  )
}

export default Home

import React from 'react'
import { Link, Routes, Route, Navigate, useRoutes } from 'react-router-dom'
import routes from './routes'
// import Course from './pages/Course'
// import CourseList from './pages/CourseList'
// import CourseDetail from './pages/CourseDetail'
// import Home from './pages/Home'
// import Login from './pages/Login'
// import User from './pages/User'
// import NotFound from './pages/NotFound'
// import RequireAuth from './components/RequireAuth'
function App(props) {
  const elements = useRoutes(routes)
  return (
    <div>
      <h3>学习路由</h3>
      <nav>
        <Link to="/">首页</Link> |<Link to="/course">课程</Link> |
        <Link to="/user/1">用户1</Link> |<Link to="/user/2">用户2</Link> |
      </nav>
      {/* 路由渲染的区域  Switch组件=》Routes */}
      {elements}
    </div>
  )
}
// function AppNoRoutesConfig(props) {
//   return (
//     <div>
//       <h3>学习路由</h3>
//       <nav>
//         <Link to="/">首页</Link> |<Link to="/course">课程</Link> |
//         <Link to="/user/1">用户1</Link> |<Link to="/user/2">用户2</Link> |
//       </nav>
//       {/* 路由渲染的区域  Switch组件=》Routes */}
//       <Routes>
//         <Route path="/" element={<Navigate to="/home"></Navigate>}></Route>
//         <Route path="/home" element={<Home></Home>}></Route>
//         <Route path="/course" element={<Course></Course>}>
//           {/* 课程列表、课程详情 */}
//           <Route index element={<CourseList></CourseList>}></Route>
//           <Route path=":name" element={<CourseDetail></CourseDetail>}></Route>
//         </Route>
//         <Route
//           path="/user/:id"
//           element={
//             <RequireAuth>
//               <User></User>
//             </RequireAuth>
//           }
//         ></Route>
//         <Route path="/login" element={<Login></Login>}></Route>

//         <Route path="*" element={<NotFound></NotFound>}></Route>
//       </Routes>
//     </div>
//   )
// }

export default App

import fs from 'fs'
import zlib from 'zlib'
const gzip = zlib.createGzip() // 压缩的对象
fs.createReadStream('./01-runnode.js')
  .pipe(gzip)
  .pipe(fs.createWriteStream('./test.zip'))

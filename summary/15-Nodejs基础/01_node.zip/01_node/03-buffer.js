const buf1 = Buffer.alloc(15)
console.log(buf1)
buf1.write('hello world')
console.log(buf1.toString('utf-8'))

//通过数据创建
const buf2 = Buffer.from('hello world')
console.log(buf2);

const buf3 = Buffer.from([11,2,3])
console.log(buf3)

const buf4 = Buffer.concat([buf1,buf2])
console.log(buf4)

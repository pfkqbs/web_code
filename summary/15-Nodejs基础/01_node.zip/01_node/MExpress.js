import Application from './application.js'
function MExpress() {
  return new Application()
}
export default MExpress

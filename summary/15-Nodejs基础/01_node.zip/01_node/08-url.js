import url from 'url'
// const myUrl = url.parse('http://localhost:8000/start?name=xiaomage&age=20')
const myUrl = new URL('http://localhost:8000/start?name=xiaomage&age=20')
console.log(myUrl.searchParams.get('name'))

// export default
// export

// module.exports = {
//   name: '小马哥',
// }
// exports.a = 10

export default {
  name:'小马哥'
}

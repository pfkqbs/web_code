// 管道流
import fs from 'fs'
// 创建可读流
const readerStream = fs.createReadStream('./01-runnode.js')
// 创建可写流
const writerStream = fs.createWriteStream('./test.txt')

readerStream.pipe(writerStream)

console.log('执行完毕')

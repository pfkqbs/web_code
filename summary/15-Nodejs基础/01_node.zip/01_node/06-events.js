import events from 'events'
// console.log(events)
const eventsEmitter = new events.EventEmitter()
eventsEmitter.on('conn', () => {
  console.log('连接成功')
  // 触发另外的事件任务
  eventsEmitter.emit('data_reveived')
})
eventsEmitter.on('data_reveived', () => {
  console.log('数据接收成功了')
})

eventsEmitter.emit('conn')
console.log('程序执行完毕')

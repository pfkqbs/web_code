import http from 'http'
import fs from 'fs'
import path from 'path'
// const http = require('http')
// const fs = require('fs')
const app = http.createServer((req, res) => {
  //   console.log(req.method, req.url)
  const { url, method } = req
  if (url === '/index' && method === 'GET') {
    //   返回首页内容 给浏览器
    fs.readFile('./static/index.html', 'utf-8', (err, data) => {
      if (err) {
        res.statusCode = 500
        res.end('500 - Interval Serval Error!')
      }
      res.statusCode = 200
      //   mime文件类型
      res.setHeader('Content-Type', 'text/html')
      res.end(data)
    })
  }
  if (url === '/about' && method === 'GET') {
    //   返回首页内容 给浏览器
    fs.readFile('./static/about.html', 'utf-8', (err, data) => {
      if (err) {
        res.statusCode = 500
        res.end('500 - Interval Serval Error!')
      }
      res.statusCode = 200
      //   mime文件类型
      res.setHeader('Content-Type', 'text/html')
      res.end(data)
    })
  }
  if (req.headers.accept.indexOf('image/*') !== -1 && method === 'GET') {
    //   流的方式
    fs.createReadStream('.' + url).pipe(res)
  }
  if (url === '/user' && method === 'GET') {
    res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ name: '小马哥' }))
  }
})

app.listen(3001, () => {
  console.log('端口在3001')
})

/* import express from 'express'
const app = express() */
import MExpress from './MExpress.js'
const app = MExpress()
// 路由
app.get('/', (req, res) => res.end('hello world'))
// app.get('/index',(req,res)=>{})
// app.get('/about',(req,res)=>{})
app.listen('3001', () => {
  console.log('监听在3001端口')
})

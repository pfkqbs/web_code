/* 
obj.fn(aaaa,(err,data)=>{

    //console.log(data)
})


异步编程的体现就是回调
异步： 不等待 非阻塞 io操作
优点：性能提高 处理大量并发请求
const a = 1
setTimeout(()=>{},2000)
const a = 2
*/
import fs from 'fs'
import { readFile } from 'fs/promises'
import { promisify } from 'util'
const readFileGenerator = promisify(fs.readFile)

// 阻塞代码 同步
// const dataBuffer = fs.readFileSync('./01-runnode.js')
// console.log(dataBuffer.toString())
// console.log('同步代码')

// 非阻塞
// fs.readFile('./01-runnode.js', (err, data) => {
//   // 错误优先机制 （一定要遵循错误优先）
//   if (err) {
//     console.log(err.stack)
//     throw err
//   }
//   console.log(data.toString())
// })
// console.log('异步代码')

// 异步代码同步化
// 1.使用async-await
/* async function asyncReadFile() {
  try {
    const data = await readFile('./01-runnode.js')
    console.log(data.toString())
  } catch (error) {
    console.log(error.stack)
  }
}
asyncReadFile() */

// 2.generator

function* read() {
  yield readFileGenerator('./01-runnode.js')
}
let ge = read()
ge.next()
  .value.then((data) => {
    console.log(data.toString())
  })
  .catch((err) => {
    console.log(err.stack)
  })

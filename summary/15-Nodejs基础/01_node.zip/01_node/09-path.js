import path from 'path'

// 在项目目录下 使用绝对路径 更准确
// console.log(path.join(__dirname,'./08-url.js')) // __filename
console.log(path.resolve('./08-url.js'))

// 获取路径文件的后缀名
console.log(path.extname('1.png'))

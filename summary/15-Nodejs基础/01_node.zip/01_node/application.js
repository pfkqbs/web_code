import http from 'http'
import url from 'url'
class Application {
  constructor() {
    // 栈 存储
    this.router = []
  }
  get(path, cb) {
    this.router.push({
      path,
      method: 'GET',
      handle: cb,
    })
  }
  listen() {
    http
      .createServer((req, res) => {
        // 获取前端给后端的url路径 pathname
        const { pathname } = url.parse(req.url)
        for (const route of this.router) {
          if (route.path === pathname) {
            route.handle(req, res)
            return
          }
          if (route.path === '*') {
            route.handle(req, res)
            return
          }
        }
      })
      .listen(...arguments)
  }
}
export default Application

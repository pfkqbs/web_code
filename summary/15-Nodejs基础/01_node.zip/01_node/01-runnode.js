// commonjs模块化规范
import c from './module.js'
import axios from 'axios'
import fs from 'fs'
console.log(fs)
// const axios = require('axios')
// const c = require('./module.cjs')
// console.log(c)
// console.log(axios)
// const a = 1
// const b = 2
// console.log(a)
// console.log(b)
// console.log(b)
// console.log(Math.random())

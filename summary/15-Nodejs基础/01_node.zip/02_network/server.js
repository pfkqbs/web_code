const express = require('express')
const app = express()
// 设置静态资源目录
app.use(express.static('public'))
app.get('/', (req, res) => {
  res.sendFile('index.html')
})
app.get('/api/user', (req, res) => {
  console.log(req.query)
  const cb = req.query.callback
  res.end(`${cb}(${JSON.stringify({ name: '小马哥' })})`)
  //   res.json({ name: '小马哥' })
})
app.listen(3001, () => {
  console.log('监听在3001端口')
})

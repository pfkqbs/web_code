"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true,
});
exports.default = void 0;

var _default = (ctx, options) => {
  // plugin 主体
  ctx.onBuildStart(() => {
    console.log("🚀 ~ file: index.js ~ line 9 ~ options", options);
    console.log("编译开始！");
  });
  ctx.onBuildFinish(() => {
    console.log("🚀 ~ file: index.js ~ line 9 ~ options", options);
    console.log("编译结束！");
  });
};

exports.default = _default;

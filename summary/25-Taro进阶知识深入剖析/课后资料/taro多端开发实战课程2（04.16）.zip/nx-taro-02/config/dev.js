module.exports = {
  env: {
    NODE_ENV: '"development"',
  },
  defineConstants: {},
  mini: {},
  h5: {
    // webpack 的配置
    devServer: {
      // 服务代理
      proxy: {
        "/api": "http://127.0.0.1:9527",
      },
    },
  },
};

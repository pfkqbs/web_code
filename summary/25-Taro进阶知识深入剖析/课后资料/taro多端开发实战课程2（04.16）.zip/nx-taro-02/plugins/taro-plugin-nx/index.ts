export default (ctx, options) => {
  // plugin 主体
  ctx.onBuildStart(() => {
    console.log("编译开始！");
  });
  ctx.onBuildFinish(() => {
    console.log("编译结束！");
  });
};

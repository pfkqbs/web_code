import {
  View,
  Button,
  Text,
  ScrollView,
  Icon,
  Switch,
} from "@tarojs/components";
import { pxTransform } from "@tarojs/taro";
import { useCallback, useState } from "react";
import { PersonContext } from "../../contexts/PersonContext";
import Person from "../../components/Person";
import "./index.scss";
import { Gender } from "src/types";

interface DetailProps {}

// Taro 不好用，其实 Taro 不想背这个锅，因为你可能在用 React 的"错误"写法写 Taro

/* 1.在写标签时，为了少出现 bug，请一定要保证内容都被标签包裹 */
/* 2.文本内容不用 Text 包裹，在进行 Android、iOS 适配时会出错 */
/* 3.有些属性却别很大，比如：height，width，单位 */
/* 4.尽量不要写死单位*/

const Detail: React.FC<DetailProps> = () => {
  const [count, setCount] = useState(0);

  const [gender, setGender] = useState<Gender>("man");
  // const list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

  // 就是一个闭包
  const handleAdd = useCallback(() => {
    // 就近取值
    setCount((prevCount) => prevCount + 1);
  }, []);

  const handleReduce = useCallback(() => {
    setCount((prevCount) => prevCount - 1);
  }, []);

  const handleGenderChange = useCallback(() => {
    setGender((prevGender) => {
      return prevGender === "man" ? "woman" : "man";
    });
  }, []);

  return (
    // <ScrollView scrollY style={{ height: pxTransform(500) }}>
    //   {/* 在写标签时，为了少出现 bug，请一定要保证内容都被标签包裹 */}
    //   {list.map((item) => (
    //     <View key={item}>
    //       {/* 文本内容不用 Text 包裹，在进行 Android、iOS 适配时会出错 */}
    //       <Icon size='60' type='success' />
    //       <Text>{item}</Text>
    //     </View>
    //   ))}
    //   {/* <Text>{count}</Text>
    //   <Text>件</Text>
    // </ScrollView>

    <View>
      <View>{count}</View>
      <PersonContext.Provider value={{ gender }}>
        <Person name="heyi" />
      </PersonContext.Provider>
      <View>
        <Button onClick={handleAdd}>+</Button>
        {/* 组件更新 props context、、、、 */}
        <Button onClick={handleReduce}>-</Button>
      </View>
      <Switch onChange={handleGenderChange} />
    </View>
  );
};

export default Detail;

import { useCallback } from "react";
import Taro from "@tarojs/taro";
import { View, Text } from "@tarojs/components";
import "./index.scss";

const Index = () => {
  const handleNavigateToDetail = useCallback(() => {
    const randomName = Math.random().toFixed(2);
    Taro.navigateTo({
      url: `/pages/hooks/index?name=${randomName}`,
    });
  }, []);
  return (
    <View className="index" onClick={handleNavigateToDetail}>
      <Text>Hello world!</Text>
    </View>
  );
};

export default Index;

import React from "react";
import { View, Text, Button } from "@tarojs/components";
import { useRouter } from "@tarojs/taro";
import Popover from "../../components/Popover";
import "./index.scss";
import usePopupState from "../../hooks/usePopupState";
import usePerson from "../../hooks/usePerson";

export interface HooksProps {}

const Hooks: React.FC<HooksProps> = () => {
  const router = useRouter();

  const { persons } = usePerson({});

  const { open, toggle } = usePopupState({ variant: "popover" });

  const {
    params: { name },
  } = router;
  return (
    <View>
      <Text>{name}</Text>
      {persons.map((person) => (
        <View key={person}>
          <Text>{person}</Text>
        </View>
      ))}
      <Popover open={open}>
        <View>
          <Text>open</Text>
        </View>
      </Popover>
      <Button onClick={toggle}>toggle</Button>
    </View>
  );
};

export default Hooks;

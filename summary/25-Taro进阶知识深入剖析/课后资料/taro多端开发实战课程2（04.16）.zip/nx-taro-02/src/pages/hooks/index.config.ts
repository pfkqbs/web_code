export default definePageConfig({
  navigationBarTitleText: 'Hook 学习'
})

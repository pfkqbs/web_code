import { useCallback, useState } from "react";

export type PopupVariant = "popover" | "popper";

export interface UsePopupState {
  variant: PopupVariant;
}

export interface UsePopupStateReturn {
  open: boolean;
  variant: PopupVariant;
  close: () => void;
  toggle: () => void;
}

const usePopupState = (props: UsePopupState): UsePopupStateReturn => {
  const { variant } = props;
  const [open, setOpen] = useState<boolean>(false);

  const close = useCallback(() => {
    setOpen(false);
  }, []);

  const toggle = useCallback(() => {
    setOpen((prevOpen) => !prevOpen);
  }, []);

  return {
    variant,
    open,
    close,
    toggle,
  };
};

export default usePopupState;

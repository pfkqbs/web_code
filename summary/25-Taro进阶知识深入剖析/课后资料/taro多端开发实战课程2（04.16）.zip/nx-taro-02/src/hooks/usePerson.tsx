import Taro, { useDidShow } from "@tarojs/taro";
import { useEffect } from "react";

export interface UsePersonState {}

export interface UsePersonStateReturn {
  persons: string[];
}

const mockPerson = ["heyi", "Nice"];

const usePerson = (props: UsePersonState): UsePersonStateReturn => {
  useDidShow(() => {
    Taro.request({
      url: "/api/user/1",
      method: "GET",
      responseType: "text",
    }).then((res) => console.log(res));
  });

  return {
    persons: mockPerson,
  };
};

export default usePerson;

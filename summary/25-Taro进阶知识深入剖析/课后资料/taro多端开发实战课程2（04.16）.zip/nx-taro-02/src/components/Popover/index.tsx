import { View } from "@tarojs/components";
import React from "react";

export interface PopoverProps {
  open: boolean;
}

const Popover: React.FC<PopoverProps> = ({ open, children }) => {
  return <View>{open && <View>{children}</View>}</View>;
};

export default Popover;

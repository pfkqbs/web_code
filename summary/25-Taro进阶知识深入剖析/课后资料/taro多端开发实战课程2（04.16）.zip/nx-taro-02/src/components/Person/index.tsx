import { View, Text } from "@tarojs/components";
import React from "react";
import { usePerson } from "../../contexts/PersonContext";
import { PersonProps, WorkProps } from "../../types";

const Work: React.FC<WorkProps> = () => {
  const { gender } = usePerson();
  return (
    <View>
      <Text>{gender}</Text>
    </View>
  );
};

const Person: React.FC<PersonProps> = ({ name }) => {
  const { gender } = usePerson();
  console.log("🚀 ~ file: index.tsx ~ line 16 ~ gender", gender);
  return <Work />;
};

export default Person;

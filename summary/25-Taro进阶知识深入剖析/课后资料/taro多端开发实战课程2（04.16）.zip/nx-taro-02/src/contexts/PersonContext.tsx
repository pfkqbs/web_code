import React, { useContext } from "react";
import { Gender } from "src/types";

export interface PersonContextValue {
  gender?: Gender;
}

export const PersonContext = React.createContext<PersonContextValue>({});

export const usePerson = () => {
  const { gender } = useContext(PersonContext);

  return {
    gender,
  };
};

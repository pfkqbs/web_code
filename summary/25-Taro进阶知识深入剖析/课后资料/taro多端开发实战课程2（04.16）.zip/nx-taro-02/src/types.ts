export type Gender = "man" | "woman";

export type PersonName = string | symbol;

export interface PersonProps {
  name: PersonName;
  gender?: Gender;
}

export interface WorkProps {
  gender?: Gender;
}

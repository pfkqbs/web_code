// person mock data
export default {
  "GET /api/user/1": {
    name: "heyi",
  },

  "POST /api/upload": {
    file: "xxx.zip",
  },
};

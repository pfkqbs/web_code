import React, { useCallback } from "react";
import { Input } from "@tarojs/components";

interface NxInputProps {
  value: string;
  onChange?: (value) => void;
}

const NxInput: React.FC<NxInputProps> = ({ value, onChange }) => {
  const handleChange = useCallback(
    (val) => {
      onChange?.(val);
    },
    [onChange]
  );
  return <Input value={value} onInput={handleChange} />;
};

export default NxInput;

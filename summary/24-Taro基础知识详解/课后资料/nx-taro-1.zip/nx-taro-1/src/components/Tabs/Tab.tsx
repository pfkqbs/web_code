import React from "react";
import { View, Text } from "@tarojs/components";
import { useTabs } from "./TabsContext";

interface TabProps {
  actived: boolean;
  tab: string;
  onClick: () => void;
}

const Tab: React.FC<TabProps> = ({ actived, tab, onClick }) => {
  // 自定义 hook 下节课详细讲解
  const { mode, toggleMode } = useTabs();
  return (
    <View
      style={{
        display: "flex",
        flexDirection: mode === "left" ? "column" : "row",
      }}
      onClick={onClick}
    >
      <Text style={{ backgroundColor: actived ? "pink" : "" }}>{tab}</Text>
      <View onClick={toggleMode}>切换模式</View>
    </View>
  );
};

export default Tab;

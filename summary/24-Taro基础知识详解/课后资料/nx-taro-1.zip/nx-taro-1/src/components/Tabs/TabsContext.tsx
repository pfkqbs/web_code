import React, { useContext } from "react";

type TabsContextValue = {
  mode: "left" | "top";
  toggleMode?: () => void;
};

export const TabsContext = React.createContext<TabsContextValue>({
  mode: "left",
});

export function useTabs() {
  const tabContext = useContext(TabsContext);
  return tabContext;
}

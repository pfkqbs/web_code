import Tabs from "./Tabs";
import Tab from "./Tab";

export { Tabs, Tab };

export default Tabs;


import React, { useEffect, useState } from "react";
import { View, Text } from "@tarojs/components";
import Tab from "./Tab";
import { TabsContext } from "./TabsContext";
import Taro from "@tarojs/taro";

// 父子组件
// 子组件之间
// 集中状态 -> redux、mobx、immer

// 国际化，换肤 Context

const Tabs: React.FC = ({ children }) => {
  const [tabIds, setTabIds] = useState([]);

  useEffect(() => {
    Taro.request({
      url: " https://cnodejs.org/api/v1/topics",
      method: "GET",
    }).then((res) => setTabIds(res.data.data.map((d) => d.title)));
  }, []);

  const [activeId, setActiveId] = useState("1");
  const [mode, setMode] = useState<"top" | "left">("top");
  return (
    <TabsContext.Provider
      value={{
        mode,
        toggleMode: () => setMode(mode === "left" ? "top" : "left"),
      }}
    >
      <View>
        {tabIds.map((tab) => (
          <Tab
            key={tab}
            tab={tab}
            actived={activeId === tab}
            onClick={() => setActiveId(tab)}
          />
        ))}
      </View>
    </TabsContext.Provider>
  );
};

export default Tabs;

import { Component } from "react";
import Taro from "@tarojs/taro";
import { View, Text, Button } from "@tarojs/components";
import "./index.scss";

// 很少使用类组件，大量使用函数式组件
export default class Index extends Component {
  componentWillMount() {}

  componentDidMount() {}

  componentWillUnmount() {}

  componentDidShow() {}

  componentDidHide() {}

  render() {
    return (
      <View className="index">
        <Text>asdfasdf</Text>
        <Button onClick={() => Taro.navigateTo({ url: "/pages/detail/index" })}>
          跳转详情
        </Button>
      </View>
    );
  }
}

// Promise
// 回调函数 callback 解决异步问题，回调地狱
// promise A+ 规范
// promise + generator
// async await

function sleep(time: number) {
  return new Promise((resolve) => {
    setTimeout(() => {
      // babel 可选链
      resolve("我睡醒啦");
    }, time);
  });
}

async function invokeSleep() {
  const res = await sleep(1000);
  console.log(res);
}

invokeSleep();

// parser 转换器
// Taro react -> weapp
// 字符串操作

// const a = 1

// babel 0.x  ATS

export default definePageConfig({
  navigationBarTitleText: '详情页'
})

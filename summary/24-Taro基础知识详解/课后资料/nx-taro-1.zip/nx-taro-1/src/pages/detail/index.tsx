import React from "react";
import Taro from "@tarojs/taro";
import { View, Text, Button } from "@tarojs/components";
import NxInput from "../../components/NxInput";
import Tabs, { Tab } from "../../components/Tabs";

const Detail: React.FC = () => {
  return (
    <View>
      <Text>详情页面</Text>
      <NxInput value="姓名" onChange={(val) => console.log(val)} />
      <Tabs>
        <Tab />
        <Tab />
      </Tabs>
      <Button onClick={() => Taro.navigateBack()}>返回</Button>
    </View>
  );
};

export default Detail;
